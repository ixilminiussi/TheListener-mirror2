// Copyright Epic Games, Inc. All Rights Reserved.

#include "TheListener.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, TheListener, "TheListener" );
