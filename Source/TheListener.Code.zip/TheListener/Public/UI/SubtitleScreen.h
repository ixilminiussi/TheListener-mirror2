// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "SubtitleScreen.generated.h"

/**
 * 
 */
UCLASS()
class THELISTENER_API USubtitleScreen : public UUserWidget
{
	GENERATED_BODY()

	void AddToContainer(class USubtitleText* Subtitle);
	void RemoveFromContainer(class USubtitleText* Subtitle);

public:
	class USubtitleText* CreateSubtitle();
	void DeleteSubtitle(class USubtitleText*);
	
protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(BindWidget))
	class UVerticalBox* SubtitleContainer;

	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<class USubtitleText> SubtitleTextClass;
};
