// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CommonUserWidget.h"
#include "DialogueWidget.generated.h"

/**
 * 
 */
UCLASS()
class THELISTENER_API UDialogueWidget : public UCommonUserWidget
{
	GENERATED_BODY()
protected:
	UPROPERTY(EditDefaultsOnly,meta=(BindWidget),Category = "System|Dialogue")
	class URichTextBlock* ContentText;

	UPROPERTY(EditDefaultsOnly,meta=(BindWidget),Category = "System|Dialogue")
	class UImage* ContinueInputImage;

public:
	void SetContinueVisibility(const ESlateVisibility NewVisibility) const;

	void SetText(const FText& NewText) const;
};
