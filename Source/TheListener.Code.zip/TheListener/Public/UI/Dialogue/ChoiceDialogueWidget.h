// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CommonUserWidget.h"
#include "ChoiceDialogueWidget.generated.h"

/**
 * 
 */
UCLASS()
class THELISTENER_API UChoiceDialogueWidget : public UCommonUserWidget
{
	GENERATED_BODY()
protected:
	UPROPERTY(meta=(BindWidget))
	class UDialogueButtonWidget* Button1;
	UPROPERTY(meta=(BindWidget))
	class UDialogueButtonWidget* Button2;
	UPROPERTY(meta=(BindWidget))
	class UDialogueButtonWidget* Button3;
	UPROPERTY(meta=(BindWidget))
	class UDialogueButtonWidget* Button4;

	UPROPERTY(meta=(BindWidget))
	class UVerticalBox* ButtonBox;

	UPROPERTY(meta=(BindWidget))
	class UButton* ContinueButton;

	UPROPERTY(meta=(BindWidget))
	class UDialogueWidget* DialogueWidget;

	TArray<class UDialogueButtonWidget*> ButtonsList;

public:
	virtual void NativeConstruct() override;
	
	UFUNCTION()
	void SelectChoice(int Choice);

	UFUNCTION()
	void Continue();

	void HideAllButtons();

	void SetButtonText(const FText& NewText, const int Choice);
	void SetButtonVisibility(ESlateVisibility NewVis, const int Choice);
	void SetDialogueText(const FText& NewText);

	void SetChoiceVisibility(ESlateVisibility NewVis);
	void SetConfirmInputVisibility(ESlateVisibility NewVis);
	void EnableConfirmInput(bool NewIsEnabled);
	void EnableContinueButton(bool NewIsEnabled);
	void SetFocusToButton();
	void SetFocusToContinueButton();
	void SetContinueButtonVisibility(ESlateVisibility NewVis);

	
	
};
