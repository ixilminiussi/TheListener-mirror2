#pragma once

#include "CoreMinimal.h"
#include "UI/Prompt/CommandWidget.h"
#include "HoverCommandWidget.generated.h"

UCLASS()
class THELISTENER_API UHoverCommandWidget : public UCommandWidget
{
	GENERATED_BODY()
};