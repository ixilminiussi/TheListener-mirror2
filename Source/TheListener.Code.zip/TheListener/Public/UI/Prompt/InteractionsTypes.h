#pragma once

#include "CoreMinimal.h"

UENUM(BlueprintType, Meta = (Bitflags))
enum class EInteractionsTypes : uint8
{
	None        = 0 UMETA(Hidden),
	Interact    = 1 << 0,
	Read     	= 1 << 1
};
ENUM_CLASS_FLAGS(EInteractionsTypes)