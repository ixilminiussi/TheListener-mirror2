#pragma once

#include "CoreMinimal.h"
#include "UI/Prompt/CommandWidget.h"
#include "ActiveCommandWidget.generated.h"

UCLASS()
class THELISTENER_API UActiveCommandWidget : public UCommandWidget
{
	GENERATED_BODY()
};