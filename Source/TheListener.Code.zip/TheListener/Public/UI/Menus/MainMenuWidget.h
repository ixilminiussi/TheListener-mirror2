#pragma once
#include "CoreMinimal.h"
#include "BaseMenuWidget.h"

#include "UI/Menus/UIElements/ButtonPrimary.h"
#include "CommonActivatableWidget.h"
#include "MainMenuWidget.generated.h"

UCLASS()
class THELISTENER_API UMainMenuWidget : public UBaseMenuWidget
{
	GENERATED_BODY()

public:
	virtual UButtonPrimary* GetFocusedButton() const override;
	
	virtual UButton* GetPreMenuButton() override;

	virtual void NativeConstruct() override;
	
protected:

	//Buttons Functions
	virtual void OnChangeLevelClicked() const override;

	virtual void OnQuitClicked() const override;

	virtual void OnSettingsClicked() const override;
	
	UFUNCTION(BlueprintCallable)
	void SetFocusOnMainMenu();


	UPROPERTY(Blueprintable ,meta = (BindWidget))
	class UButton* PreMenuButton;

	
};