// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CommonUserWidget.h"
#include "SettingsTabBase.h"
#include "SettingsAudioWidget.generated.h"

/**
 * 
 */
UCLASS()
class THELISTENER_API USettingsAudioWidget : public USettingsTabBase
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

protected:
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
	class USliderSettings* UISlider;
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
	class USliderSettings* VoiceSlider;
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
	class USliderSettings* SoundEffectSlider;
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
	class USliderSettings* NoiseRadioSlider;
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
	class USliderSettings* MusicSlider;
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
	class USliderSettings* MusicRadioSlider;
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
	class USliderSettings* MasterSlider;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category="Audio Bus")
	class UAkRtpc* MasterAudioBus;

	UFUNCTION()
	void OnMasterSliderValueChanged(float Value);
};
