// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CommonActivatableWidget.h"
#include "BaseMenuWidget.generated.h"

/**
 * 
 */
UCLASS()
class THELISTENER_API UBaseMenuWidget : public UCommonActivatableWidget
{
	GENERATED_BODY()
	
public:
	virtual class UButtonPrimary* GetFocusedButton() const;

	virtual void NativeConstruct() override;

	UFUNCTION()
	virtual class UButton* GetPreMenuButton();

protected:

	// Buttons Functions
	UFUNCTION()
	virtual void OnChangeLevelClicked() const;

	UFUNCTION(BlueprintImplementableEvent)
	void OnStartLoadingScreen() const;
	UFUNCTION()
	void LoadNextLevel() const;

	UFUNCTION()
	virtual void OnSettingsClicked() const;

	UFUNCTION()
	virtual void OnQuitClicked() const;

	
	// Widgets Button
	UPROPERTY(EditAnywhere ,meta = (BindWidget))
	UButtonPrimary* ChangeLevelButton;

	UPROPERTY(meta = (BindWidget))
	UButtonPrimary* SettingsButton;
	
	UPROPERTY(meta = (BindWidget))
	UButtonPrimary* QuitButton;


	// Variables for GD
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Menus", meta = (AllowedClasses="World"))
	TSoftObjectPtr<UWorld> NewLevel;

};
