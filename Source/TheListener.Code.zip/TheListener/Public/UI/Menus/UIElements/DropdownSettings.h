// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ButtonUIElement.h"
#include "DropdownSettings.generated.h"

/**
 * 
 */
UCLASS()
class THELISTENER_API UDropdownSettings : public UButtonUIElement
{
	GENERATED_BODY()
	
public:
	virtual void NativeConstruct() override;
	
	virtual void NativeOnClicked() override;
	
protected:
	UPROPERTY(meta = (BindWidget))
	class UCommonAnimatedSwitcher* Switcher;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Dropdown|Value")
	TArray<FText> DropdownValues;

	// Text
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
	class URichTextBlock* RichTextBlock;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Dropdown|Name")
	FText NameText;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category="Dropdown")
	TSubclassOf<class URichTextBlocDropDown> RichTextBlocDropDownClass;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category="Dropdown")
	class UDataTable* TextStyle;

	UFUNCTION()
	void CreateTextBlock(FText Text);

	UPROPERTY()
	bool bIsSelected = false;
};
