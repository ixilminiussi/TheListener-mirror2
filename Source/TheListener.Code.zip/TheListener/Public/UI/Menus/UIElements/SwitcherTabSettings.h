// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CommonUserWidget.h"
#include "CommonActivatableWidgetSwitcher.h"
#include "SwitcherTabSettings.generated.h"

UCLASS()
class THELISTENER_API USwitcherTabSettings : public UCommonUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	class UCommonAnimatedSwitcher* GetAnimatedSwitcher() const;

protected:
	UPROPERTY(meta = (BindWidget))
	class USettingsTabBase* GameplayTab;

	UPROPERTY(meta = (BindWidget))
	class USettingsTabBase* AudioTab;

	UPROPERTY(meta = (BindWidget))
	class USettingsTabBase* GraphicsTab;

	UPROPERTY(meta = (BindWidget))
	class USettingsTabBase* AccessibilityTab;

	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
	UCommonActivatableWidgetSwitcher* AnimatedSwitcher;

public:
	UFUNCTION()
	USettingsTabBase* GetGameplayTab() const;
	UFUNCTION()
	USettingsTabBase* GetAudioTab() const;
	UFUNCTION()
	USettingsTabBase* GetGraphicsTab() const;
	UFUNCTION()
	USettingsTabBase* GetAccessibilityTab() const;
};
