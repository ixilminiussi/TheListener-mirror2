// Copyright (c) 2025 ArtFX. Created by Team FalseStart. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "CommonUserWidget.h"
#include "RichTextBlocDropDown.generated.h"

/**
 * 
 */
UCLASS()
class THELISTENER_API URichTextBlocDropDown : public UCommonUserWidget
{
	GENERATED_BODY()

	void NativeConstruct() override;

public:
	UFUNCTION()
	class URichTextBlock* GetRichTextBlock() const;
	
protected:
	UPROPERTY(meta=(BindWidget))
	class URichTextBlock* RichTextBlock;

	UPROPERTY(EditAnywhere, Category="TextDropDown|Name")
	FText Text;
};
