// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ButtonUIElement.h"
#include "SliderSettings.generated.h"

/**
 * 
 */

UCLASS()
class THELISTENER_API USliderSettings : public UButtonUIElement
{
	GENERATED_BODY()

public:
	class USlider* GetSlider() const;

	class URichTextBlock* GetValueRichTextBlock() const;

protected:
	virtual void NativeConstruct() override;

	virtual void NativeOnHovered() override;

	virtual void NativeOnUnhovered() override;

	virtual FReply NativeOnPreviewKeyDown(const FGeometry& InGeometry, const FKeyEvent& InKeyEvent) override;

	virtual FReply
	NativeOnAnalogValueChanged(const FGeometry& InGeometry, const FAnalogInputEvent& InAnalogEvent) override;


	// Slider
	UPROPERTY(BlueprintReadWrite, meta = (BindWidget))
	class USlider* Slider;

	UPROPERTY()
	class USlider* CurrentSlider;

	bool bEnabled{false};

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Slider|Values")
	float SliderMin;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Slider|Values")
	float SliderMax;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Slider|Values")
	float SliderStepSize;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Slider|Values")
	float SliderTempDefaultValue;

	//Text
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
	class URichTextBlock* RichTextBlock;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Slider|Name")
	FText Text;

	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
	class URichTextBlock* ValueRichTextBlock;

	UPROPERTY()
	bool bIsHolding = false;

	UPROPERTY()
	float HoldTimer = 0.f;

	UPROPERTY()
	float HoldRepeatDelay = 0.2f;

	UPROPERTY()
	float HoldRepeatRate = 0.05f;

	UPROPERTY()
	int AxisDirection = 0;

	UPROPERTY()
	float RepeatAccumulator = 0.f;

	UPROPERTY()
	class ABaseHUD* HUD;

private:
	UPROPERTY()
	float LastCall = 0;

public:
	UFUNCTION()
	void OnLeftDpadClicked();
	UFUNCTION()
	void OnRightDpadClicked();

	UFUNCTION()
	void SetNumberSlider(float Value) const;

	UFUNCTION()
	void StepOnceGamepad(float StepAmount);
};
