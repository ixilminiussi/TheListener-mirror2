// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ButtonUIElement.h"
#include "CheckBoxSettings.generated.h"

/**
 * 
 */
UCLASS()
class THELISTENER_API UCheckBoxSettings : public UButtonUIElement
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	class UCheckBox* GetCheckBox() const;
	
protected:
	UPROPERTY(meta = (BindWidget))
	class UCheckBox* CheckBox;

	// Text
	UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
	class URichTextBlock* RichTextBlock;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="CheckBox|Name")
	FText Text;
	
};

