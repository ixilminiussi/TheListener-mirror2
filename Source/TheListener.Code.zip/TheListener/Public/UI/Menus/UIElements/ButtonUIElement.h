// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CommonButtonBase.h"
#include "ButtonUIElement.generated.h"

/**
 * 
 */
UCLASS()
class THELISTENER_API UButtonUIElement : public UCommonButtonBase
{
	GENERATED_BODY()

protected:
	virtual void NativeConstruct() override;

	virtual void NativeOnClicked() override;
	
	UPROPERTY()
	bool bIsEditing = false;
	
	UPROPERTY(EditAnywhere, Category="UIElementNavigation")
	UButtonUIElement* UpUIElement;

	UPROPERTY(EditAnywhere, Category="UIElementNavigation")
	UButtonUIElement* DownUIElement;
};
