// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/SaveGame.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "SettingsSave.generated.h"

/**
 * 
 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnSettingsChanged);

UCLASS()
class THELISTENER_API USettingsSave : public USaveGame
{
	GENERATED_BODY()

protected:
	// Runtime Values
	// Gameplay
	UPROPERTY(EditDefaultsOnly, Category = "Gameplay")
	float HorizontalSensitivity;
	UPROPERTY(EditDefaultsOnly, Category = "Gameplay")
	float VerticalSensitivity;
	UPROPERTY(EditDefaultsOnly, Category = "Gameplay")
	bool ControllerHapticFeedback;

	//Audio
	UPROPERTY(EditDefaultsOnly, Category = "Audio")
	float MasterVolume;

public:
	UPROPERTY(EditDefaultsOnly, Category = "Events")
	FOnSettingsChanged OnSettingsChanged;

	// Events

	UFUNCTION()
	void InitializeFromDefaults(class USettingsDataAsset* DefaultData);

	// Setters
	// Gameplay
	UFUNCTION()
	void SetHorizontalSensitivity(float Value);
	UFUNCTION()
	void SetVerticalSensitivity(float Value);
	UFUNCTION()
	void SetControllerHapticFeedback(bool bValue);

	// Audio
	UFUNCTION()
	void SetMasterVolume(float Value);


	// Getters
	// Gameplay
	UFUNCTION()
	float GetHorizontalSensitivity() const;
	UFUNCTION()
	float GetVerticalSensitivity() const;
	UFUNCTION()
	bool GetControllerHapticFeedback() const;

	// Audio
	UFUNCTION()
	float GetMasterVolume() const;
};
