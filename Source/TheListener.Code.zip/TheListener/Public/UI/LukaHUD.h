#pragma once

#include "CoreMinimal.h"
#include "BaseHUD.h"

#include "LukaHUD.generated.h"

enum class EInteractionsTypes : uint8;
#define TOP_LEVEL 100000

UCLASS()
class THELISTENER_API ALukaHUD : public ABaseHUD
{
	GENERATED_BODY()

public:
	UFUNCTION()
	void OnBeginInteractiveInViewEvent();
	UFUNCTION()
	void OnEndInteractiveInViewEvent();
	UFUNCTION()
	void OnBeginToyPossessEvent();
	UFUNCTION()
	void OnEndToyPossessEvent();

	class USubtitleScreen* GetSubtitleWidget();

	void AddHoverCommandWidget(class UHoverCommandWidget* HoverCommandWidget) const;
	void RemoveHoverCommandWidget(class UHoverCommandWidget* HoverCommandWidget) const;
	void AddActiveCommandWidget(class UActiveCommandWidget* ActiveCommandWidget) const;
	void RemoveActiveCommandWidget(class UActiveCommandWidget* ActiveCommandWidget) const;

protected:
	virtual void BeginPlay() override;

	UPROPERTY(EditDefaultsOnly, Category = "LukaHUD|Widget")
	TSubclassOf<class UCommonActivatableWidget> MainWidgetClass = nullptr;

	UPROPERTY(BlueprintReadOnly)
	TObjectPtr<class UPlayWidget> PlayWidget = nullptr;

	UPROPERTY() // TODO consider removing
	TObjectPtr<class UCursorWidget> CursorWidget = nullptr;

	UPROPERTY() // TODO consider removing
	TObjectPtr<USubtitleScreen> SubtitleWidget = nullptr;

	UPROPERTY()
	TObjectPtr<class UCommonActivatableWidget> EndPanelWidgetInstance = nullptr;

	virtual UBaseMenuWidget* GetPreviousWidget() override;

	virtual USettingsMenuWidget* GetSettingsMenuWidget() const override;

	UFUNCTION(BlueprintCallable)
	class UCommonActivatableWidget* GetEndPanelWidget() const;

public:
	UFUNCTION()
	void PauseGame();

	UFUNCTION()
	void ResumeGame();

	UFUNCTION(BlueprintNativeEvent)
	void HandleAnswerInput() const;

protected:
	UPROPERTY(EditDefaultsOnly, Category="LukaHUD|Enhanced Inputs")
	TObjectPtr<class UInputMappingContext> InputMappingContext;

	UPROPERTY(EditAnywhere, Category = "Widget|Menus")
	TSubclassOf<class UCommonUserWidget> EndPanelWidgetClass;
};
