#pragma once
#include "CoreMinimal.h"
#include "CommonActivatableWidget.h"
#include "PlayWidget.generated.h"

UCLASS()
class THELISTENER_API UPlayWidget : public UCommonActivatableWidget
{
	GENERATED_BODY()
	
public:
	class UCursorWidget* GetCursorWidget() const;
	class USubtitleScreen* GetSubtitleWidget();
	void AddHoverCommandWidget(class UHoverCommandWidget* HoverCommandWidget) const;
	void RemoveHoverCommandWidget(class UHoverCommandWidget* HoverCommandWidget) const;
	void AddActiveCommandWidget(class UActiveCommandWidget* ActiveCommandWidget) const;
	void RemoveActiveCommandWidget(class UActiveCommandWidget* ActiveCommandWidget) const;
	
protected:
	UPROPERTY(meta = (BindWidget))
	class UCursorWidget* CursorWidget;

	UPROPERTY(meta = (BindWidget))
	class UVerticalBox* VerticalBox = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UVerticalBox* ActiveVerticalBox = nullptr;

	UPROPERTY(meta = (BindWidget))
	class USubtitleScreen* SubtitleWidget = nullptr;
};