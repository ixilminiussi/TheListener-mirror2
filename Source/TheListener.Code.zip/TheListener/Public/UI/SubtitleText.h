// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CommonUserWidget.h"
#include "AkGameplayStatics.h"
#include "SubtitleText.generated.h"


/**
 * 
 */
UCLASS()
class THELISTENER_API USubtitleText : public UCommonUserWidget
{
	GENERATED_BODY()
public:
	void SetText(FString NewText);

protected:
	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class URichTextBlock* SubtitleText;

};

