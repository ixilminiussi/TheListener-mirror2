#pragma once

#include "CoreMinimal.h"
#include "CommonInputBaseTypes.h"
#include "BaseCommonInputPlatformSettings.generated.h"

UCLASS()
class THELISTENER_API UBaseCommonInputPlatformSettings : public UCommonInputPlatformSettings
{
	GENERATED_BODY()
	
};