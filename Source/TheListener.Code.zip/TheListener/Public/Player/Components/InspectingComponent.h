// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "InspectingComponent.generated.h"


UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class THELISTENER_API UInspectingComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UInspectingComponent();

	void TurnOnTranslation(const struct FInputActionInstance&);
	void TurnOffTranslation(const struct FInputActionInstance&);

	class UInputMappingContext* GetInputMappingContext() const;

protected:
	virtual void BeginPlay() override;

	void Leave(const struct FInputActionInstance&);
	void Read(const struct FInputActionInstance&);
	void ReadFile(const class IInspectable*);

	class ALukaCharacter* LukaCharacter;

	TWeakObjectPtr<class UEnhancedInputLocalPlayerSubsystem> WeakInputLocalPlayerSubsystem;

	UPROPERTY()
	class UInspectWidget* CurrentWidget = nullptr;

	UPROPERTY(EditAnywhere)
	class UCommandHUDComponent* CommandHUDComponent = nullptr;

	// inputs ===========================================
public:
	virtual void SetupInput(UEnhancedInputComponent*,
	                        UEnhancedInputLocalPlayerSubsystem*);

protected:
	UPROPERTY(EditAnywhere, Category = "ReadingComponent|Enhanced Input")
	class UInputAction* InputActionVisibilityText;
	UPROPERTY(EditAnywhere, Category = "ReadingComponent|Enhanced Input")
	class UInputAction* InputActionRead;
	UPROPERTY(EditAnywhere, Category = "ReadingComponent|Enhanced Input")
	class UInputAction* InputActionLeave;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "ReadingComponent|Enhanced Input")
	class UInputMappingContext* InputMappingContext;
	// inputs ===========================================
};
