#pragma once

#include "Inspectable.generated.h"

UINTERFACE(MinimalAPI)
class UInspectable : public UInterface
{
	GENERATED_BODY()
};

class IInspectable
{
	GENERATED_BODY()

public:
	virtual TSubclassOf<class UInspectWidget> GetInspectWidget() const = 0;
};
