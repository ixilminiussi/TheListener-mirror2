#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "LukaCharacter.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnMove, float, Speed);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnStartMoving);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnStopMoving);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnBeginAnyInView);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnEndAnyInView);

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnBeginSpecificInView, class AActor *, Actor);

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnEndSpecificInView, class AActor *, Actor);

UENUM()
enum class ELukaState : uint8
{
	ELS_Default UMETA(DisplayName = "Default"),
	ELS_Busy UMETA(DisplayName = "Busy",
		Detailed = "Whenever Luka cannot move due to performing an action or possessing a toy"),
};


UCLASS()
class THELISTENER_API ALukaCharacter : public ACharacter
{
	GENERATED_BODY()

public:
	ALukaCharacter();
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;

	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	void MapPlayerData(const class UPlayerData*);

	UFUNCTION()
	void MapSettingsData();

	friend class ALukaController;

protected:
	virtual void PossessedBy(AController* NewController) override;
	virtual void UnPossessed() override;

	UPROPERTY(EditDefaultsOnly, Category = "Luka", meta = (Tooltip = "Takes precedences over everything else"))
	TObjectPtr<class UPlayerData> PlayerData;
	UPROPERTY(EditDefaultsOnly, Category = "Luka")
	TObjectPtr<class USettingsDataAsset> SettingsData;
	// Basic Controls Begin
public:
	class UInputMappingContext* GetLukaMappingContext() const;

protected:
	void Look(const struct FInputActionValue& Value);
	void Move(const struct FInputActionValue& Value);
	void OnMove_Event(float Speed);
	void OnStartMoving_Event(const struct FInputActionValue& Value);
	void OnStopMoving_Event(const struct FInputActionValue& Value);

	UFUNCTION(BlueprintImplementableEvent, Category = "Luka")
	void Look_();
	UFUNCTION(BlueprintImplementableEvent, Category = "Luka")
	void Move_(float VelocityMagnitude);

	UFUNCTION(BlueprintImplementableEvent, Category = "Luka")
	void Step_(float Intensity);

	float MinFootstepDistance;
	float MaxFootstepDistance;
	float MaxFootstepTime;

	UPROPERTY(EditDefaultsOnly, Category = "Luka|Enhanced Input")
	class UInputAction* InputActionLook;
	UPROPERTY(EditDefaultsOnly, Category = "Luka|Enhanced Input")
	class UInputAction* InputActionMove;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Luka|Enhanced Input")
	class UInputMappingContext* InputMappingContext;

	float HorizontalSensitivity;
	float VerticalSensitivity;

	float LateralMaxWalkSpeed;
	float BackwardMaxWalkSpeed;

	UPROPERTY(EditDefaultsOnly, Category = "Luka")
	TObjectPtr<class USpringArmComponent> SpringArmComponent;
	UPROPERTY(EditDefaultsOnly, Category = "Luka")
	TObjectPtr<class UCameraComponent> CameraComponent;
	UPROPERTY(EditDefaultsOnly, Category = "Luka")
	TObjectPtr<class UHandComponent> HandComponent;

public:
	TObjectPtr<class UHandComponent> GetHandComponent() const;


	UPROPERTY(BlueprintAssignable, Category = "Luka|Events")
	FOnMove OnMove;
	UPROPERTY(BlueprintAssignable, Category = "Luka|Events")
	FOnStartMoving OnStartMoving;
	UPROPERTY(BlueprintAssignable, Category = "Luka|Events")
	FOnStartMoving OnStopMoving;
	// Basic Controls End

	// Interactives Begin
	UPROPERTY(BlueprintAssignable, Category = "Luka|Events")
	FOnBeginAnyInView OnBeginAnyInView;
	UPROPERTY(BlueprintAssignable, Category = "Luka|Events")
	FOnEndAnyInView OnEndAnyInView;

	UPROPERTY(BlueprintAssignable, Category = "Luka|Events")
	FOnBeginSpecificInView OnBeginSpecificInView;
	UPROPERTY(BlueprintAssignable, Category = "Luka|Events")
	FOnBeginSpecificInView OnEndSpecificInView;

	float GetInteractiveMaxRange() const { return InteractionMaxRange; }
	bool HasObji() const;
	class AObji* GetHeldObji() const;

protected:
	UPROPERTY(EditDefaultsOnly, Category = "Luka|Interaction")
	float InteractionMaxRange{50.f};

	UPROPERTY(EditDefaultsOnly, Category = "Luka|Interaction")
	TEnumAsByte<ECollisionChannel> InteractiveCollisionChannel;

	void InteractiveRayCheck();
	// Toys Begin
public:
	class AToy* GetToyInView() const;

protected:
	UPROPERTY()
	TObjectPtr<class AToy> ToyInView;
	// Toys End

	// Interactables Begin

	void Interact();

public:
	UFUNCTION(BlueprintCallable, Category = "Luka|Obji")
	void PickupObji(class AObji* Obji);
	UFUNCTION(BlueprintCallable, Category = "Luka|Obji")
	AObji* DropObji();
	class AInteractable* GetInteractableInView() const;

protected:
	UPROPERTY()
	class AInteractable* InteractableInView;
	// Interactables End

	// Snap to Ground Begin
public:
	void SnapToGround(float DistanceCheck = 1000.f);
	// CR LookAtToy ?= Snap To Ground ?
	void LookAtToy(const class AToy* Toy);

protected:
	UPROPERTY(EditDefaultsOnly, Category = "Luka|World")
	TEnumAsByte<ECollisionChannel> FloorCollisionChannel;
	// Snap to Ground End

public:
	ELukaState LukaState = ELukaState::ELS_Default;

	ELukaState SetLukaState(ELukaState CurrentLukaState);
	ELukaState GetLukaState();
};
