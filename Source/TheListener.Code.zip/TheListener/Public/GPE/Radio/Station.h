#pragma once

#include "CoreMinimal.h"
#include "AkGameplayTypes.h"
#include "GameFramework/Actor.h"
#include "Station.generated.h"

UCLASS()
class THELISTENER_API AStation : public AActor
{
	GENERATED_BODY()

	// Station ================================
public:
	friend class FCogGameplayWindow_Utilities;

	AStation();
	virtual void Destroyed() override;
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	UFUNCTION(BlueprintNativeEvent, Category = "Station")
	void Initialize();

	/**
	 * Starts Ak Event, and subtitles
	 */
	UFUNCTION(BlueprintCallable, Category = "Station")
	void StartStation();
	/**
	 * Stops Ak Event, and subtitles
	 */
	UFUNCTION(BlueprintCallable, Category = "Station")
	void StopStation();
	float UpdateSound(const float InFrequency);

	virtual void SetupStation(class UStationAsset* StationDataAsset, class ARadio* RadioActor);
	class UStationAsset* GetStationData() const;

	UFUNCTION(BlueprintCallable, Category = "Station")
	bool IsInRange(float InFrequency) const;
	void EnterRange();
	void LeaveRange();

	UFUNCTION(BlueprintCallable, Category = "Station")
	void Lock(bool bEnable);

	void Decode();

protected:
	UPROPERTY(BlueprintReadOnly, Category = "Station")
	bool bWasInRange = false;

	UFUNCTION(BlueprintNativeEvent, Category = "Station")
	void OnDecoded();
	virtual void OnDecoded_Implementation();
	UFUNCTION(BlueprintNativeEvent, Category = "Station")
	void OnStartStation();
	virtual void OnStartStation_Implementation();
	UFUNCTION(BlueprintNativeEvent, Category = "Station")
	void OnStopStation();
	virtual void OnStopStation_Implementation();

	UFUNCTION(BlueprintNativeEvent, Category = "Station")
	void OnEnteringStationRange();
	virtual void OnEnteringStationRange_Implementation();
	UFUNCTION(BlueprintNativeEvent, Category = "Station")
	void OnLeavingStationRange();
	virtual void OnLeavingStationRange_Implementation();

	UFUNCTION(BlueprintCallable, Category = "Station")
	void PostAkEvent();
	void PostAkEndEvent();
	UFUNCTION()
	virtual void OnAkEventCallback(EAkCallbackType CallbackType, UAkCallbackInfo* CallbackInfo);
	void SetStationData(class UStationAsset* StationDataAsset);
	void SetRadio(class ARadio* RadioActor);
	
public:
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable, Category = "Dialogue")
	void OnAnswerOpened();
	virtual void OnAnswerOpened_Implementation();

public:
	UFUNCTION(BlueprintCallable, Category = "Station")
	int32 GetPlayPosition();

protected:
	int32 PlayingID;

	UPROPERTY(BlueprintReadOnly, Category = "Station")
	TObjectPtr<class UStationAsset> StationData = nullptr;
	UPROPERTY()
	TObjectPtr<class ARadio> Radio = nullptr;
	UPROPERTY(BlueprintReadOnly, Category = "Station")
	TObjectPtr<class UAkComponent> AkComponent = nullptr;
	UPROPERTY(BlueprintReadOnly, Category = "Station")
	bool bIsPlaying = false;
	// Station End ============================

	// Subtitles ==============================
public:
	void SetCorruptionCurve(UCurveFloat* InCurve);

protected:
	UFUNCTION(BlueprintCallable, Category = "Station")
	void CreateSubtitles();
	void UpdateSubtitles(EAkCallbackType CallbackType, UAkCallbackInfo* CallbackInfo);
	void UpdateText();
	void DestroySubtitles();

	UPROPERTY()
	TObjectPtr<class USubtitleText> SubtitlesWidget = nullptr;
	FOnAkPostEventCallback AkPostEventCallback;

	FString LastPureLine;

	UPROPERTY()
	TObjectPtr<class UCurveFloat> CorruptionCurve;
	float CurrentCorruption;
	float TimeToScrambleLetter = 0.025f;
	FTimerHandle ScrambleTimer;
	// Subtitles End ==========================

	// Dialogue ==============================
public:
	UFUNCTION(BlueprintCallable, Category = "Station|Dialogue")
	class UAnswerDataAsset* GetAnswerData();

	UFUNCTION(BlueprintCallable, Category = "Station|Dialogue")
	class UAkSwitchValue* GetSwitchValue();

protected:
	UFUNCTION(BlueprintCallable, Category = "Station|Dialogue")
	void SelectAnswer(class UAkSwitchValue* InValue);

	UPROPERTY(EditDefaultsOnly, Category = "Station|Dialogue")
	TObjectPtr<class UAkSwitchValue> DefaultSwitchValue;
	UPROPERTY()
	TObjectPtr<class UAkSwitchValue> DialogueSwitchValue;

	// Should be pure virtual functions but it doesn't work for BlueprintImplementableEvent
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Station|Dialogue")
	void OnAnswerSelected();
	UFUNCTION(BlueprintImplementableEvent, Category = "Station|Dialogue")
	void OnFinishDialoguePart();
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Station|Dialogue")
	struct FTimerHandle GetGameplayTimer();
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Station|Dialogue")
	void UpdateTimer();
	// End Dialogue ==========================
};
