#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "AnswerDataAsset.generated.h"

class UConstantQNRT;
class UAkSwitchValue;

USTRUCT(BlueprintType)
struct FAnswer
{
	GENERATED_BODY()
	
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	FText Answer = {};
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	UAkSwitchValue* NextState = nullptr;
};

USTRUCT(BlueprintType)
struct FAnswerList
{
	GENERATED_BODY()
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	TArray<FAnswer> Answers;
};

UCLASS(BlueprintType)
class THELISTENER_API UAnswerDataAsset : public UDataAsset
{
	GENERATED_BODY()
	
public:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	TMap<UAkSwitchValue*, FAnswerList> AssociatedQuestions;
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	TMap<UAkSwitchValue*, UConstantQNRT*> AssociatedConstantQNRT;
	
};