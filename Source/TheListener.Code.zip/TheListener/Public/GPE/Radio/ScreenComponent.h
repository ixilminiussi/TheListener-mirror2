#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ScreenComponent.generated.h"


UCLASS()
class THELISTENER_API AScreenComponent : public AActor
{
	GENERATED_BODY()

public:
	AScreenComponent();

protected:
	virtual void BeginPlay() override;

public:
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable)
	void GenerateNoiseArray();
	virtual void Tick(float DeltaTime) override;

	UFUNCTION(BlueprintCallable)
	float GetImpactFloat() const;
	
	UFUNCTION(BlueprintImplementableEvent)
	void SetNiagaraFloatArray(const TArray<float>& Array);

	void SetRadio(class ARadio* Radio);

protected:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	class UNiagaraComponent* NiagaraComponent = nullptr;
	
	UPROPERTY(EditDefaultsOnly)
	UStaticMeshComponent* Plane = nullptr;

	UPROPERTY()
	class UConstantQNRT* ConstantQnrt = nullptr;

	UPROPERTY()
	class ARadio* Parent = nullptr;

	TArray<float> AudioNiagaraFloatArray{};

	UPROPERTY(BlueprintReadWrite )
	TArray<float> NoiseNiagaraFloatArray{};
};
