// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Station.h"
#include "Engine/DataAsset.h"
#include "StationDataAsset.generated.h"

UCLASS()
class THELISTENER_API UStationAsset : public UDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<class AStation> StationClass = AStation::StaticClass();

	UPROPERTY(EditDefaultsOnly, Category = "Audio")
	FString StationName{};

	UPROPERTY(EditDefaultsOnly, Category = "Audio")
	TObjectPtr<class UAkAudioEvent> StartAudioEvent;

	UPROPERTY(EditDefaultsOnly, Category = "Audio")
	TObjectPtr<class UAkAudioEvent> StopAudioEvent;

	// Needs a Sound Wave for the Screen Component to work
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, meta=(EditCondition = "AnswerDataAsset == nullptr", EditConditionHides, Category = "Audio"))
	class UConstantQNRT* ConstantQnrt = nullptr;

	UPROPERTY(EditDefaultsOnly, Category = "Audio")
	TObjectPtr<class UAkRtpc> Rtpc;

	UPROPERTY(EditDefaultsOnly,BlueprintReadOnly, Category = "Audio",
		meta = (ClampMin = "0.01", ClampMax = "20000.0", DisplayPrecision = "2"))
	float Frequency = .0f;

	UPROPERTY(EditDefaultsOnly, Category = "Audio",
		meta = (ClampMin = "0.01", ClampMax = "200.0", DisplayPrecision = "2"))
	float ReceptionBand = 50.f;

	TStaticArray<struct FKeyHandle, 3> CurveKeys{};

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Dialogue")
	TObjectPtr<class UAnswerDataAsset> AnswerDataAsset = nullptr;

	UPROPERTY(EditDefaultsOnly, Category = "Decoder")
	bool bIsEncoded = false;

	UPROPERTY(EditDefaultsOnly, Category = "Decoder",
		meta = (EditCondition = "bIsEncoded", ToolTip = "The sound that is played until it is decoded"))
	TObjectPtr<class UAkAudioEvent> DecoderStartAudioEvent;
	UPROPERTY(EditDefaultsOnly, Category = "Decoder", meta = (EditCondition = "bIsEncoded"))
	TObjectPtr<class UAkAudioEvent> DecoderEndAudioEvent;
};
