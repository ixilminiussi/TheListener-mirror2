#pragma once

#include "CoreMinimal.h"
#include "GPE/Toy.h"
#include "Radio.generated.h"

/* DEPRECATED
UENUM()
enum class EFrequencyControlType : uint8
{
	EFCT_Spin = 0 UMETA(DisplayName = "Spin"),
	EFCT_Shift UMETA(DisplayName = "Shift")
};
*/

UCLASS(Blueprintable)
class THELISTENER_API ARadio : public AToy
{
	GENERATED_BODY()

	friend class FCogGameplayWindow_Utilities;

protected:
	ARadio();
	virtual void OnConstruction(const FTransform& Transform) override;
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;
	virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;;
	virtual void Destroyed() override;
	virtual void PossessedBy(AController* NewController) override;
	virtual void UnPossessed() override;

	void StartRadio();
	void StopRadio();

	// Stations Begin =========================
public:
	class AStation* CreateStationObject(class UStationAsset* StationData);
	class AStation* GetStationFromDataAsset(const class UStationAsset* StationData);
	void ForgetStationObject(class AStation* Station);

protected:
	UPROPERTY()
	TArray<TObjectPtr<class AStation>> Stations{};
	// Stations End ===========================

	// Sound Begin ============================
public:
	void UpdateStations();
	TSet<TObjectPtr<class AStation>> GetStationsInRange() const;

protected:
	TSet<TObjectPtr<class AStation>> StationsInRange;

	UPROPERTY(EditDefaultsOnly, Category = "Toy|Radio|Stations")
	TObjectPtr<class USceneComponent> SoundPosition = nullptr;

	UPROPERTY()
	TObjectPtr<class UAkComponent> RadioAkComponent = nullptr;
	UPROPERTY(EditDefaultsOnly, Category = "Toy|Radio")
	TObjectPtr<class UAkAudioEvent> NoiseStartEvent = nullptr;
	UPROPERTY(EditDefaultsOnly, Category = "Toy|Radio")
	TObjectPtr<class UAkAudioEvent> NoiseStopEvent = nullptr;

public:
	UPROPERTY(EditDefaultsOnly, Category = "Toy|Radio")
	TObjectPtr<class UAkRtpc> NoiseRtpc = nullptr;

	UPROPERTY(BlueprintReadOnly)
	float HighestStationInterest = 0.f;
	// Sound End ==============================

	// Inputs Begin ===========================
	void Lock(bool bEnable, AStation* Station = nullptr);

protected:
	UFUNCTION(BlueprintImplementableEvent, Category = "Toy|Radio")
	void OnLock(bool bEnable, AStation* Station = nullptr);
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Toy|Enhanced Input")
	class UInputMappingContext* AnswerInputMappingContext;
	UPROPERTY(EditDefaultsOnly, Category = "Toy|Radio|Enhanced Input")
	TObjectPtr<class UInputAction> InputActionShiftFrequency = nullptr;
	UPROPERTY(EditDefaultsOnly, Category = "Toy|Radio|Enhanced Input")
	TObjectPtr<class UInputAction> InputActionAnswer = nullptr;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Toy|Enhanced Input")
	class UInputMappingContext* DeactivateRadioInputMappingContext;

	/* DEPRECATED
	UPROPERTY(EditDefaultsOnly, Category = "Toy|Radio|Enhanced Input")
	TObjectPtr<class UInputAction> InputActionSpinFrequency = nullptr;
	
	UPROPERTY(EditDefaultsOnly, Category = "Toy|Radio|Controls")
	EFrequencyControlType FrequencyControlType = EFrequencyControlType::EFCT_Spin;
	*/

	// Triggers
	UPROPERTY(EditDefaultsOnly, Category = "Toy|Radio|Controls|Triggers",
		meta = (ClampMin = "0.1", ClampMax = "1000.0"))
	float Sensitivity = 800.f;

	//Joystick
	UPROPERTY(EditDefaultsOnly, Category = "Toy|Radio|Controls|Joystick", meta = (ClampMin = "0.01", ClampMax = "1.0"))
	float MinimumRollInputRegister = .6f;
	bool bIsNotFirstRollAngle = false;
	float LastAngle = .0f;
	// Inputs End =============================

	// Frequency Begin ========================
public:
	FVector2d GetFrequencyRange() const;

protected:
	void ShiftFrequency(const struct FInputActionValue& Value);

	UPROPERTY(EditDefaultsOnly, Category = "Toy|Radio", meta = (ClampMin = "0.0", ClampMax = "20000.0"))
	float StartFrequency = 10000.f;
	UPROPERTY(EditDefaultsOnly, Category = "Toy|Radio", meta = (ClampMin = "0.0", ClampMax = "20000.0"))
	FVector2D FrequencyRange{};

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Toy|Radio")
	TObjectPtr<class UKnobComponent> KnobComponent{nullptr};
	// Frequency End ==========================

	// Decoder Begin ========================
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Toy|Radio|Decoder")
	TObjectPtr<class UChildActorComponent> DecoderComponent{nullptr};
	UPROPERTY()
	TObjectPtr<class ADecoder> Decoder{nullptr};

	UPROPERTY(EditDefaultsOnly, Category = "Toy|Radio|Decoder")
	TSubclassOf<class ADecoder> DecoderComponentClass;

	bool bWasTrue = false;
	// Decoder End ==========================

	// Assets Begin ===========================
	UPROPERTY(EditDefaultsOnly, Category = "Toy|Radio")
	TObjectPtr<class UTextRenderComponent> TextRenderComponent{nullptr};
	UPROPERTY(EditDefaultsOnly, Category = "Toy|Radio")
	TObjectPtr<class UWidgetComponent> WidgetComponent{nullptr};
	UPROPERTY(EditDefaultsOnly, Category = "Toy|Radio")
	TSubclassOf<class URadioText> TextWidgetClass{nullptr};
	UPROPERTY(EditDefaultsOnly, Category = "Toy|Radio")
	TObjectPtr<class UStaticMeshComponent> BaseMeshComponent{nullptr};

	void UpdateVisuals() const;
	void UpdateText() const;
	// Assets End =============================

	// Subtitles Begin ========================
	UPROPERTY(Category = "Toy|Radio|Subtitles", EditDefaultsOnly)
	TObjectPtr<UCurveFloat> CorruptionCurve;
	// Subtitles End ==========================

	// Answer Begin ========================
	UFUNCTION()
	void ActivateAnswers();
	// Answer End ==========================

	// Screen Begin ========================
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Toy|Radio|Screen")
	TObjectPtr<class UChildActorComponent> ScreenComponent{nullptr};
	UPROPERTY()
	TObjectPtr<class AScreenComponent> Screen{nullptr};

	UPROPERTY(EditDefaultsOnly, Category = "Toy|Radio|Screen")
	TSubclassOf<class AScreenComponent> ScreenComponentClass;
	// Screen End ==========================
};
