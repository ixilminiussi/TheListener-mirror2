#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Pawn.h"
#include "Toy.generated.h"

UCLASS()
class THELISTENER_API AToy : public APawn
{
	GENERATED_BODY()

public:
	AToy();

	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
	class UInputMappingContext* GetInputMappingContext() const;

	UFUNCTION(BlueprintCallable, Category = "Toy")
	const class UCameraComponent* GetCameraComponent() const;

	UFUNCTION(BlueprintCallable, Category = "Toy|Interactive")
	void Lock(bool bEnable);
	bool IsLocked() const;
	bool IsEnabled() const;

	UFUNCTION(BlueprintCallable, Category = "Toy|Interactive")
	void Enable(bool bToggle);
	void Highlight(bool bToggle);

protected:
	virtual void BeginPlay() override;
	virtual void PossessedBy(AController* NewController) override;
	virtual void UnPossessed() override;

	UPROPERTY(EditDefaultsOnly, Category="Toy|Interactive")
	class UMaterial* HighlightMaterial;

	UPROPERTY(EditInstanceOnly, Category="Toy", BlueprintReadWrite)
	class UCameraComponent* CameraComponent;

	UPROPERTY(EditDefaultsOnly, Category="Toy|Interactive")
	class UBoxComponent* CollisionComponent;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Toy|Enhanced Input")
	class UInputMappingContext* InputMappingContext;

	bool bLocked{false};
	bool bEnabled{true};

	bool bIsPossessed{false};

	UPROPERTY(EditDefaultsOnly, Category = "Toy|Interactive")
	float CameraDistanceBack{20.0f};

public:
	float GetCameraDistanceBack() const;

	// Feedbacks ==============================
	void OnPossessToyTransition();
	void OnUnpossessToyTransition();
	void SetHoverWidgetVisibility(const bool bIsVisible) const;
	void SetActiveWidgetVisibility(const bool bIsVisible) const;

protected:
	UPROPERTY(EditDefaultsOnly)
	class UCommandHUDComponent* CommandHUDComponent = nullptr;

	UPROPERTY()
	class UAkComponent* AkComponent{nullptr};
	UPROPERTY(EditDefaultsOnly, Category = "Toy|Feedbacks")
	class UAkAudioEvent* OnPossessTransitionAkEvent{nullptr};
	UPROPERTY(EditDefaultsOnly, Category = "Toy|Feedbacks")
	class UAkAudioEvent* OnUnpossessTransitionAkEvent{nullptr};
	// Feedbacks End ==============================
};
