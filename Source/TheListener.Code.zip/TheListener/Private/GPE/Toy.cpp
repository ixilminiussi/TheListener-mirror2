#include "GPE/Toy.h"

#include "AkComponent.h"
#include "EnhancedInputSubsystems.h"
#include "Components/BoxComponent.h"
#include "Components/SceneComponent.h"
#include "Camera/CameraComponent.h"
#include "Engine/LocalPlayer.h"
#include "UI/Prompt/CommandHUDComponent.h"
#include "EventSubsystem.h"
#include "Kismet/GameplayStatics.h"
#include "System/Events/EventCondition.h"

AToy::AToy()
{
	PrimaryActorTick.bCanEverTick = false;

	CollisionComponent = CreateDefaultSubobject<UBoxComponent>("Collision");
	check(CollisionComponent);

	SetRootComponent(CollisionComponent);
	CollisionComponent->SetCollisionProfileName(FName("Hitbox"));

	CameraComponent = CreateDefaultSubobject<UCameraComponent>("Camera");
	check(CameraComponent);

	CameraComponent->SetupAttachment(CollisionComponent);

	CommandHUDComponent = CreateDefaultSubobject<UCommandHUDComponent>("CommandHUDComponent");

	AkComponent = CreateDefaultSubobject<UAkComponent>("AkComponent");
	AkComponent->SetupAttachment(RootComponent);
	AkComponent->SetRelativeLocation(FVector::ZeroVector);
	check(AkComponent);
}

void AToy::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
}

UInputMappingContext* AToy::GetInputMappingContext() const
{
	return InputMappingContext;
}

const UCameraComponent* AToy::GetCameraComponent() const
{
	return CameraComponent;
}

void AToy::Lock(const bool bEnable)
{
	if (!InputMappingContext)
	{
		return;
	}

	bLocked = bEnable;

	if (bLocked) // remove InputMappingContext
	{
		if (const APlayerController* PlayerController = Cast<APlayerController>(
			UGameplayStatics::GetPlayerController(GetWorld(), 0)))
		{
			UEnhancedInputLocalPlayerSubsystem* InputSubsystem = PlayerController->GetLocalPlayer()->GetSubsystem<
				UEnhancedInputLocalPlayerSubsystem>();

			InputSubsystem->RemoveMappingContext(InputMappingContext);
			SetActiveWidgetVisibility(false);
		}
	}
	else // bring back InputMappingContext
	{
		if (const APlayerController* PlayerController = Cast<APlayerController>(
			UGameplayStatics::GetPlayerController(GetWorld(), 0)))
		{
			UEnhancedInputLocalPlayerSubsystem* InputSubsystem = PlayerController->GetLocalPlayer()->GetSubsystem<
				UEnhancedInputLocalPlayerSubsystem>();

			InputSubsystem->AddMappingContext(InputMappingContext, 1);
			SetActiveWidgetVisibility(true);
		}
	}
}

bool AToy::IsLocked() const
{
	return bLocked;
}

bool AToy::IsEnabled() const
{
	return bEnabled;
}

void AToy::Enable(const bool bToggle)
{
	bEnabled = bToggle;
}

void AToy::Highlight(const bool bToggle)
{
	if (!IsEnabled())
	{
		return;
	}

	static bool LastCall = false;
	if (bToggle == LastCall)
	{
		return;
	}
	LastCall = bToggle;

	TArray<UStaticMeshComponent*> StaticMeshComponents;
	GetComponents<UStaticMeshComponent>(StaticMeshComponents);

	if (!ensure(HighlightMaterial))
	{
		return;
	}
	for (UStaticMeshComponent* StaticMeshComponent : StaticMeshComponents)
	{
		if (bToggle)
		{
			StaticMeshComponent->SetOverlayMaterial(HighlightMaterial);
		}
		else
		{
			StaticMeshComponent->SetOverlayMaterial(nullptr);
		}
	}
}

void AToy::BeginPlay()
{
	Super::BeginPlay();

	check(CommandHUDComponent);

	CommandHUDComponent->Generate(InputMappingContext);
}

void AToy::PossessedBy(AController* NewController)
{
	Super::PossessedBy(NewController);

	APlayerController* PlayerController = Cast<APlayerController>(NewController);
	if (!PlayerController)
	{
		return;
	}

	EnableInput(PlayerController);
	bIsPossessed = true;

	if (!InputMappingContext)
	{
		return;
	}

	UEnhancedInputLocalPlayerSubsystem* InputSubsystem = PlayerController->GetLocalPlayer()->GetSubsystem<
		UEnhancedInputLocalPlayerSubsystem>();
	InputSubsystem->AddMappingContext(InputMappingContext, 1);

	if (UEventSubsystem* EventSubsystem = GetWorld()->GetSubsystem<UEventSubsystem>(); ensure(EventSubsystem))
	{
		const FConditionKey Key = UToyPossessedCondition::GenerateKey(GetClass());
		EventSubsystem->SetConditionValue(Key, true, true);
	}

	SetActiveWidgetVisibility(true);
}

void AToy::UnPossessed()
{
	bIsPossessed = false;

	if (!InputMappingContext)
	{
		return;
	}

	if (const APlayerController* PlayerController = Cast<APlayerController>(GetController()))
	{
		UEnhancedInputLocalPlayerSubsystem* InputSubsystem = PlayerController->GetLocalPlayer()->GetSubsystem<
			UEnhancedInputLocalPlayerSubsystem>();
		InputSubsystem->RemoveMappingContext(InputMappingContext);

		const FConditionKey Key = UToyPossessedCondition::GenerateKey(GetClass());

		const auto EventSubsystem = GetWorld()->GetSubsystem<UEventSubsystem>();
		check(EventSubsystem);
		EventSubsystem->SetConditionValue(Key, false, true);
	}

	Super::UnPossessed();
}

float AToy::GetCameraDistanceBack() const
{
	return CameraDistanceBack;
}

void AToy::OnPossessToyTransition()
{
	SetHoverWidgetVisibility(false);
	if (OnPossessTransitionAkEvent)
	{
		check(AkComponent);
		FOnAkPostEventCallback NullCallback;
		AkComponent->PostAkEvent(OnPossessTransitionAkEvent, 0, NullCallback);
	}
}

void AToy::OnUnpossessToyTransition()
{
	SetActiveWidgetVisibility(false);
	if (OnUnpossessTransitionAkEvent)
	{
		check(AkComponent);
		FOnAkPostEventCallback NullCallback;
		AkComponent->PostAkEvent(OnUnpossessTransitionAkEvent, 0, NullCallback);
	}
}

void AToy::SetHoverWidgetVisibility(const bool bIsVisible) const
{
	if (!bEnabled)
	{
		return;
	}

	check(CommandHUDComponent);
	if (bIsVisible)
	{
		CommandHUDComponent->AddHoverToHUD();
	}
	else
	{
		CommandHUDComponent->RemoveHoverFromHUD();
	}
}

void AToy::SetActiveWidgetVisibility(const bool bIsVisible) const
{
	check(CommandHUDComponent);
	if (bIsVisible)
	{
		CommandHUDComponent->AddActiveToHUD();
	}
	else
	{
		CommandHUDComponent->RemoveActiveFromHUD();
	}
}
