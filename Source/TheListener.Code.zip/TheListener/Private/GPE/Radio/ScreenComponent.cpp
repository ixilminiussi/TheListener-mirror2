#include "GPE/Radio/ScreenComponent.h"

#include "ConstantQNRT.h"
#include "GPE/Radio/AnswerDataAsset.h"
#include "GPE/Radio/Radio.h"
#include "GPE/Radio/Station.h"
#include "GPE/Radio/StationDataAsset.h"
#include "Niagara/Public/NiagaraComponent.h"

AScreenComponent::AScreenComponent()
{
	PrimaryActorTick.bCanEverTick = true;

	Plane = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("ScreenStaticMesh"));
	Plane->SetupAttachment(RootComponent);
	check(Plane);
	
	NiagaraComponent = CreateDefaultSubobject<UNiagaraComponent>(TEXT("NiagaraComponent"));
	NiagaraComponent->SetupAttachment(Plane);
	check(NiagaraComponent);
}

void AScreenComponent::BeginPlay()
{
	Super::BeginPlay();
}

void AScreenComponent::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (Parent)
	{
		TObjectPtr<AStation> CurrentHearingStation = nullptr;

		for (const TObjectPtr<class AStation>& Station : Parent->GetStationsInRange())
		{
			CurrentHearingStation = Station;
			break;
		}

		TArray<float> OutputNiagaraFloatArray;
		OutputNiagaraFloatArray.Init(0.f, 48);
		
		for (int i = 0; i < OutputNiagaraFloatArray.Num(); i++)
		{
			OutputNiagaraFloatArray[i] += NoiseNiagaraFloatArray[i]; 
		}

		if (CurrentHearingStation)
		{
			if (const class UStationAsset* StationData = CurrentHearingStation->GetStationData())
			{
				if (NiagaraComponent)
				{
					// Get is a station with dialogues
					if (StationData->AnswerDataAsset)
					{
						if (const class UAkSwitchValue* CurrentSwitchValue = CurrentHearingStation->GetSwitchValue(); CurrentSwitchValue)
						{
							ConstantQnrt = *StationData->AnswerDataAsset->AssociatedConstantQNRT.Find(CurrentSwitchValue);
						}
					}
					else
					{
						ConstantQnrt = StationData->ConstantQnrt;
					}
					// if so get the current switch
					// then get the associated sound wave
					// if no do the current stuff

					if (ConstantQnrt)
					{
						if (ConstantQnrt->Sound)
						{
							float CurrentPlayingPosition = CurrentHearingStation->GetPlayPosition() / 1000.f;
							ConstantQnrt->GetNormalizedChannelConstantQAtTime(CurrentPlayingPosition, 0, AudioNiagaraFloatArray);

							for (int i = 0; i < OutputNiagaraFloatArray.Num(); i++)
							{
								OutputNiagaraFloatArray[i] += AudioNiagaraFloatArray[i] * (1-GetImpactFloat()); 
							}
						}
					}
				}
			}
		}
		SetNiagaraFloatArray(OutputNiagaraFloatArray);
	}
}

float AScreenComponent::GetImpactFloat() const
{
	if (Parent)
	{
		return (1-Parent->HighestStationInterest);
	}
	return .0f;
}

void AScreenComponent::SetRadio(class ARadio* Radio)
{
	Parent = Radio;
}
