#include "GPE/Radio/Station.h"
#include "AkComponent.h"
#include "AkSwitchValue.h"
#include "GPE/Radio/Radio.h"
#include "GPE/Radio/StationDataAsset.h"
#include "Kismet/GameplayStatics.h"
#include "Miscellaneous/TLUtils.h"
#include "EventSubsystem.h"
#include "System/Events/EventCondition.h"
#include "System/Frequency/FrequencySubsystem.h"
#include "UI/LukaHUD.h"
#include "UI/SubtitleScreen.h"
#include "UI/SubtitleText.h"

AStation::AStation()
{
	PrimaryActorTick.bCanEverTick = true;

	AkComponent = CreateDefaultSubobject<UAkComponent>(TEXT("AkComponent"));
	AkComponent->SetupAttachment(RootComponent);
}

void AStation::Destroyed()
{
	Super::Destroyed();
	if (SubtitlesWidget)
	{
		SubtitlesWidget->ConditionalBeginDestroy();
	}
}

void AStation::BeginPlay()
{
	Super::BeginPlay();
}

void AStation::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
	auto FrequencySubsystem = GetWorld()->GetSubsystem<UFrequencySubsystem>();
	check(FrequencySubsystem);
	FrequencySubsystem->ForgetStation(this);
}

void AStation::Initialize_Implementation()
{
	CreateSubtitles();
	StartStation();
}

void AStation::StartStation()
{
	check(StationData);
	check(AkComponent);

	if (!StationData->StartAudioEvent)
	{
		UE_LOG(LogTemp, Warning,
		       TEXT("Missing 'Start Audio Event' in Station data asset — the station will never start without it."));
		return;
	}
	if (!StationData->StopAudioEvent)
	{
		UE_LOG(LogTemp, Warning,
		       TEXT("Missing 'Stop Audio Event' in station data asset — the station will never stop without it."));
	}

	OnStartStation();
}

void AStation::StopStation()
{
	OnStopStation();
}

float AStation::UpdateSound(const float InFrequency)
{
	bool bIsInRange = IsInRange(InFrequency);

	if (!bIsInRange && !bWasInRange)
	{
		AkComponent->SetRTPCValue(StationData->Rtpc, 0.f, 0, StationData->Rtpc->GetName());
		return 0.f;
	}
	if (!bWasInRange && bIsInRange)
	{
		OnEnteringStationRange();
	}
	else if (bWasInRange && !bIsInRange)
	{
		OnLeavingStationRange();
	}

	if (!ensure(CorruptionCurve))
	{
		bWasInRange = bIsInRange;
		return 0.;
	}

	if (!StationData->Rtpc)
	{
		UE_LOG(LogTemp, Warning,
		       TEXT("Missing 'RTPC' in Station data asset — the volume will never change without it."));

		bWasInRange = bIsInRange;
		return .0f;
	}

	if (bWasInRange || bIsInRange)
	{
		const float RtpcValue = 1.0f - (FMath::Abs(StationData->Frequency - InFrequency) / StationData->ReceptionBand);
		if (LastPureLine != "" && ensure(SubtitlesWidget))
		{
			CurrentCorruption = CorruptionCurve->GetFloatValue(RtpcValue);
			if (SubtitlesWidget->GetVisibility() == ESlateVisibility::Visible)
			{
				UpdateText();
			}
		}
		AkComponent->SetRTPCValue(StationData->Rtpc, RtpcValue, 0, StationData->Rtpc->GetName());

		UE_LOG(LogTemp, Warning, TEXT("%f"), RtpcValue);

		bWasInRange = bIsInRange;
		return RtpcValue;
	}

	bWasInRange = bIsInRange;
	return .0f;
}

void AStation::PostAkEvent()
{
	bIsPlaying = true;

	const FName CBName("OnAkEventCallback");
	AkPostEventCallback.BindUFunction(this, CBName);
	PlayingID = AkComponent->PostAkEvent(StationData->StartAudioEvent,
	                                     AK_Marker | AK_MusicSyncUserCue | AK_EndOfEvent | AK_EnableGetMusicPlayPosition
	                                     |
	                                     AK_EnableGetSourcePlayPosition,
	                                     AkPostEventCallback);

	if (ensure(StationData->Rtpc))
	{
		AkComponent->SetRTPCValue(StationData->Rtpc, 0.f, 0, StationData->Rtpc->GetName());
	}

	check(PlayingID != AK_INVALID_PLAYING_ID);
	/* alors gars, en faite, le son que t'as mis sur ta station il est pas valid
	 * donc soit tu l'as pas mis du tous, soit ta oublie de regenerer tes soundbanks
	 * c'est pas complique putain
	 * fait des efforts */
}

void AStation::PostAkEndEvent()
{
	check(bIsPlaying);
	check(StationData);
	check(AkComponent);

	FOnAkPostEventCallback NullCallback;
	PlayingID = AkComponent->PostAkEvent(StationData->StopAudioEvent, 0, NullCallback);
}

void AStation::OnAkEventCallback(EAkCallbackType CallbackType, UAkCallbackInfo* CallbackInfo)
{
	switch (CallbackType)
	{
	case EAkCallbackType::Marker:
	case EAkCallbackType::MusicSyncUserCue:
		UpdateSubtitles(CallbackType, CallbackInfo);
		break;
	case EAkCallbackType::EndOfEvent:
		if (!StationData->AnswerDataAsset)
		{
			StopStation();
		}
		break;
	default:
		break;
	}
}

void AStation::SetupStation(UStationAsset* StationDataAsset, ARadio* RadioActor)
{
	SetStationData(StationDataAsset);
	SetRadio(RadioActor);

	Initialize();
}

UStationAsset* AStation::GetStationData() const
{
	return StationData;
}

void AStation::SetStationData(UStationAsset* StationDataAsset)
{
	StationData = StationDataAsset;
}

void AStation::SetRadio(ARadio* RadioActor)
{
	Radio = RadioActor;
}

void AStation::OnAnswerOpened_Implementation()
{
}

void AStation::SetCorruptionCurve(UCurveFloat* InCurve)
{
	CorruptionCurve = InCurve;
}

void AStation::CreateSubtitles()
{
	GetWorldTimerManager().SetTimer(ScrambleTimer, this, &AStation::UpdateText, TimeToScrambleLetter, true,
	                                0.0f);

	ALukaHUD* HUD = Cast<ALukaHUD>(UGameplayStatics::GetPlayerController(GetWorld(), 0)->GetHUD());
	if (ensure(HUD))
	{
		SubtitlesWidget = HUD->GetSubtitleWidget()->CreateSubtitle();
		SubtitlesWidget->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void AStation::UpdateSubtitles(EAkCallbackType CallbackType, UAkCallbackInfo* CallbackInfo)
{
	switch (CallbackType)
	{
	case EAkCallbackType::Marker:
		if (Cast<UAkMarkerCallbackInfo>(CallbackInfo)->Label == "end")
		{
			if (StationData->AnswerDataAsset)
			{
				OnFinishDialoguePart();
			}
		}
		else
		{
			LastPureLine = Cast<UAkMarkerCallbackInfo>(CallbackInfo)->Label;
		}
		break;
	case EAkCallbackType::MusicSyncUserCue:
		LastPureLine = Cast<UAkMusicSyncCallbackInfo>(CallbackInfo)->UserCueName;
		break;
	default:
		break;
	}
}

void AStation::UpdateText()
{
	if (SubtitlesWidget && LastPureLine != "")
	{
		if (!SubtitlesWidget->IsVisible()) { return; }
		//Get a "Unique" Seed for each subtitle
		int CurrentSeed = LastPureLine.Len();
		int Corruption = CurrentCorruption * 100;
		FString NewString;
		for (int i = 0; i < LastPureLine.Len(); i++)
		{
			if (CurrentSeed == 0) { CurrentSeed = 10000; }
			CurrentSeed = LastPureLine[i] * CurrentSeed % 1000000;
			FMath::RandInit(CurrentSeed);
			int RandomID = FMath::RandHelper(100);
			if (RandomID > Corruption && LastPureLine[i] != 32)
			{
				FMath::RandInit(static_cast<int>((i + 1) * 10000 * UGameplayStatics::GetTimeSeconds(this)) % 100000);
				char rChar = FMath::RandRange(65, 116);
				if (rChar > 90) { rChar += 6; }
				NewString.AppendChar(rChar);
			}
			else
			{
				NewString.AppendChar(LastPureLine[i]);
			}
		}

		SubtitlesWidget->SetText(NewString);
	}
}

void AStation::DestroySubtitles()
{
	if (SubtitlesWidget != nullptr)
	{
		APlayerController* PlayerController = UGameplayStatics::GetPlayerController(GetWorld(), 0);
		if (PlayerController)
		{
			if (ALukaHUD* HUD = Cast<ALukaHUD>(PlayerController->GetHUD()); ensure(HUD))
			{
				HUD->GetSubtitleWidget()->DeleteSubtitle(SubtitlesWidget);
				SubtitlesWidget = nullptr;
			}
		}
	}
}

class UAkSwitchValue* AStation::GetSwitchValue()
{
	if (!IsValid(DialogueSwitchValue))
	{
		return DefaultSwitchValue;
	}

	return DialogueSwitchValue;
}

void AStation::SelectAnswer(class UAkSwitchValue* InValue)
{
	DialogueSwitchValue = InValue;
	OnAnswerSelected();
}

class UAnswerDataAsset* AStation::GetAnswerData()
{
	check(StationData);
	return StationData->AnswerDataAsset;
}

int32 AStation::GetPlayPosition()
{
	const int32 PlayPosition = UTLUtils::GetPlayPosition(PlayingID);

	return PlayPosition;
}

bool AStation::IsInRange(float InFrequency) const
{
	check(StationData);

	const float DistanceCurrentFrequency = FMath::Abs(StationData->Frequency - InFrequency);
	return DistanceCurrentFrequency <= StationData->ReceptionBand;
}

void AStation::EnterRange()
{
	OnEnteringStationRange();
}

void AStation::LeaveRange()
{
	AkComponent->SetRTPCValue(StationData->Rtpc, 0.f, 0, StationData->Rtpc->GetName());
	OnLeavingStationRange();
}

void AStation::Lock(bool bEnable)
{
	Radio->Lock(bEnable, this);
}

void AStation::Decode()
{
	OnDecoded();
}

void AStation::OnDecoded_Implementation()
{
	check(Radio);
	Radio->Lock(true, this);
}

void AStation::OnStopStation_Implementation()
{
	check(Radio);
	Radio->Lock(false);
	PostAkEndEvent();
	DestroySubtitles();

	// send condition
	const FConditionKey Key = UStationFinishedCondition::GenerateKey(StationData);
	if (const auto EventSubsystem = GetWorld()->GetSubsystem<UEventSubsystem>())
	{
		EventSubsystem->SetConditionValue(Key, true);
	}

	Destroy();
}

void AStation::OnStartStation_Implementation()
{
	PostAkEvent();
}

void AStation::OnEnteringStationRange_Implementation()
{
	if (ensure(SubtitlesWidget))
	{
		SubtitlesWidget->SetVisibility(ESlateVisibility::Visible);
	}
	FConditionKey Key = UStationListenedCondition::GenerateKey(StationData);
	const auto EventSubsystem = GetWorld()->GetSubsystem<UEventSubsystem>();
	check(EventSubsystem);
	EventSubsystem->SetConditionValue(Key, true);
}

void AStation::OnLeavingStationRange_Implementation()
{
	if (ensure(SubtitlesWidget))
	{
		SubtitlesWidget->SetVisibility(ESlateVisibility::Collapsed);
	}
}
