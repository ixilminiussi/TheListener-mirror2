#include "GPE/Radio/Radio.h"
#include "EnhancedInputComponent.h"
#include "AkGameplayStatics.h"
#include "AkGameplayTypes.h"
#include "AkComponent.h"
#include "EnhancedInputSubsystems.h"
#include "Components/TextRenderComponent.h"
#include "Components/WidgetComponent.h"
#include "GPE/Obji.h"
#include "Player/LukaController.h"
#include "GPE/Radio/KnobComponent.h"
#include "GPE/Radio/Decoder.h"
#include "GPE/Radio/PrimaryStation.h"
#include "GPE/Radio/ScreenComponent.h"
#include "GPE/Radio/StationDataAsset.h"
#include "GPE/Radio/Station.h"
#include "Kismet/GameplayStatics.h"
#include "Miscellaneous/TLUtils.h"
#include "UI/LukaHUD.h"
#include "UI/RadioText.h"

ARadio::ARadio()
{
	PrimaryActorTick.bCanEverTick = true;

	check(RootComponent);
	SoundPosition = CreateDefaultSubobject<USceneComponent>("SoundPosition");
	SoundPosition->SetupAttachment(RootComponent);
	check(SoundPosition);

	RadioAkComponent = CreateDefaultSubobject<UAkComponent>("RadioAkComponent");
	RadioAkComponent->SetupAttachment(SoundPosition);
	RadioAkComponent->SetRelativeLocation(FVector::ZeroVector);
	check(RadioAkComponent);

	BaseMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>("BaseMesh");
	BaseMeshComponent->SetupAttachment(RootComponent);
	check(BaseMeshComponent);

	KnobComponent = CreateDefaultSubobject<UKnobComponent>("Knob");
	KnobComponent->SetupAttachment(BaseMeshComponent);
	check(KnobComponent);

	DecoderComponent = CreateDefaultSubobject<UChildActorComponent>("DecoderComponent");
	DecoderComponent->SetupAttachment(RootComponent);
	check(DecoderComponent);

	ScreenComponent = CreateDefaultSubobject<UChildActorComponent>("ScreenComponent");
	ScreenComponent->SetupAttachment(RootComponent);
	check(ScreenComponent);

	WidgetComponent = CreateDefaultSubobject<UWidgetComponent>("FrequencyDisplay");
	WidgetComponent->SetupAttachment(RootComponent);
	check(WidgetComponent);
}

void ARadio::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);
	if (DecoderComponentClass)
	{
		DecoderComponent->SetChildActorClass(DecoderComponentClass);
	}
	if (ScreenComponentClass)
	{
		ScreenComponent->SetChildActorClass(ScreenComponentClass);
	}
}

void ARadio::BeginPlay()
{
	Super::BeginPlay();

	// Setup Knob
	if (!ensure(KnobComponent))
	{
		UE_LOG(LogTemp, Error,
		       TEXT("Missing Knob Component"));
		return;
	}

	KnobComponent->SetRange(FrequencyRange);
	KnobComponent->SetValue(StartFrequency);

	if (!ensure(ScreenComponent))
	{
		UE_LOG(LogTemp, Error,
		       TEXT("Missing Screen Component"));
		return;
	}

	if (AScreenComponent* ScreenActor = Cast<AScreenComponent>(ScreenComponent->GetChildActor()))
	{
		ScreenActor->SetRadio(this);
	}

	if (!ensure(WidgetComponent))
	{
		return;
	}

	const FText NewText = FText::FromString(FString::Printf(TEXT("%.0f Hz"), KnobComponent->GetValue()));
	if (ensure(TextWidgetClass))
	{
		WidgetComponent->SetWidgetClass(TextWidgetClass);
		WidgetComponent->InitWidget();
		URadioText* RefRadioText = Cast<URadioText>(WidgetComponent->GetWidget());
		check(RefRadioText);
		RefRadioText->SetRadioText(NewText);
	}

	if (!ensure(DecoderComponent))
	{
		return;
	}

	if (ADecoder* DecoderActor = Cast<ADecoder>(DecoderComponent->GetChildActor()))
	{
		Decoder = DecoderActor;
		Decoder->SetRadio(this);
	}

	ALukaController* LukaController = Cast<ALukaController>(UGameplayStatics::GetPlayerController(GetWorld(), 0));
	if (!ensure(LukaController))
	{
		return;
	}
	LukaController->OnUnpossessToyTransition.AddDynamic(Decoder, &ADecoder::OnEndToyPossessEvent);
}

void ARadio::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);
	if (bIsPossessed)
	{
		UpdateVisuals();
		UpdateStations();
	}
}

void ARadio::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	UEnhancedInputComponent* EnhancedInputComponent = Cast<UEnhancedInputComponent>(InputComponent);

	if (!ensure(EnhancedInputComponent))
	{
		return;
	}

	EnhancedInputComponent->BindAction(InputActionShiftFrequency, ETriggerEvent::Triggered, this,
	                                   &ARadio::ShiftFrequency);

	EnhancedInputComponent->BindAction(InputActionAnswer, ETriggerEvent::Started, this,
	                                   &ARadio::ActivateAnswers);

	if (ensure(Decoder))
	{
		Decoder->SetupPlayerInputComponent(EnhancedInputComponent);
	}
}

void ARadio::Destroyed()
{
	StopRadio();

	for (AStation* Station : Stations)
	{
		if (Station)
		{
			Station->Destroy();
		}
	}

	Stations.Empty();
	StationsInRange.Empty();

	Super::Destroyed();
}

void ARadio::PossessedBy(AController* NewController)
{
	Super::PossessedBy(NewController);
	if (ALukaController* LukaController = Cast<ALukaController>(NewController))
	{
		StartRadio();
	}

	APlayerController* PlayerController = Cast<APlayerController>(NewController);
	if (!PlayerController)
	{
		return;
	}
	if (!AnswerInputMappingContext)
	{
		return;
	}

	UEnhancedInputLocalPlayerSubsystem* InputSubsystem = PlayerController->GetLocalPlayer()->GetSubsystem<
		UEnhancedInputLocalPlayerSubsystem>();
	InputSubsystem->AddMappingContext(AnswerInputMappingContext, 1);
}

void ARadio::UnPossessed()
{
	Super::UnPossessed();
	StopRadio();
}

AStation* ARadio::CreateStationObject(UStationAsset* StationData)
{
	check(StationData);
	check(SoundPosition);

	FActorSpawnParameters SpawnParameters;
	SpawnParameters.Owner = this;
	AStation* NewStation = GetWorld()->SpawnActor<AStation>(StationData->StationClass,
	                                                        FVector::ZeroVector, FRotator::ZeroRotator,
	                                                        SpawnParameters);

	NewStation->AttachToComponent(SoundPosition,
	                              FAttachmentTransformRules::KeepRelativeTransform);
	NewStation->SetupStation(StationData, this);
	NewStation->SetCorruptionCurve(CorruptionCurve);
	Stations.Add(NewStation);
	return NewStation;
}

AStation* ARadio::GetStationFromDataAsset(const UStationAsset* StationData)
{
	for (AStation* StationActor : Stations)
	{
		if (!ensure(StationActor)) { continue; }
		if (StationActor->GetStationData() == StationData)
		{
			return StationActor;
		}
	}
	return nullptr;
}

void ARadio::ForgetStationObject(AStation* Station)
{
	check(Station);

	Stations.Remove(Station);
	StationsInRange.Remove(Station);
}

void ARadio::StartRadio()
{
	// Start Noise
	if (!ensure(NoiseStartEvent))
	{
		UE_LOG(LogTemp, Warning,
		       TEXT("Missing 'Noise Start Event' in Radio class defaults — the radio will never start without it."));
		return;
	}
	if (!ensure(NoiseStopEvent))
	{
		UE_LOG(LogTemp, Warning,
		       TEXT("Missing 'Noise Stop Event' in Radio class defaults — the radio will never stop without it."));
		return;
	}
	check(RadioAkComponent);

	FOnAkPostEventCallback NullCallback;
	RadioAkComponent->PostAkEvent(NoiseStartEvent, 0, NullCallback);
}

void ARadio::StopRadio()
{
	for (auto It = StationsInRange.CreateIterator(); It; ++It)
	{
		AStation* Station = *It;
		if (!ensure(Station))
		{
			continue;
		}

		Station->LeaveRange();
		It.RemoveCurrent();
	}

	// Stop Noise
	if (!ensure(NoiseStartEvent))
	{
		UE_LOG(LogTemp, Warning,
		       TEXT("Missing 'Noise Start Event' in Radio class defaults — the radio will never start without it."));
		return;
	}
	if (!ensure(NoiseStopEvent))
	{
		UE_LOG(LogTemp, Warning,
		       TEXT("Missing 'Noise Stop Event' in Radio class defaults — the radio will never stop without it."));
		return;
	}

	check(RadioAkComponent);
	const FOnAkPostEventCallback NullCallback;
	RadioAkComponent->PostAkEvent(NoiseStopEvent, 0, NullCallback);

	if (Decoder)
	{
		Decoder->StopDecoder();
	}
}

void ARadio::UpdateStations()
{
	HighestStationInterest = 0.f;

	check(KnobComponent);
	float Frequency = KnobComponent->GetValue();

	for (TObjectPtr<AStation> Station : Stations)
	{
		if (!ensure(Station))
		{
			continue;
		}

		if (Station->IsInRange(Frequency))
		{
			if (!StationsInRange.Contains(Station))
			{
				StationsInRange.Add(Station);
				Station->EnterRange();
			}
		}
		else
		{
			if (StationsInRange.Contains(Station))
			{
				StationsInRange.Remove(Station);
				Station->LeaveRange();
			}
		}

		HighestStationInterest = FMath::Max(Station->UpdateSound(Frequency), HighestStationInterest);
	}

	if (NoiseRtpc != nullptr)
	{
		HighestStationInterest = FMath::Clamp(HighestStationInterest, 0.f, 1.f);
		RadioAkComponent->SetRTPCValue(NoiseRtpc, HighestStationInterest, 0, NoiseRtpc->GetName());
	}

	else UE_LOG(LogTemp, Warning,
	            TEXT("Missing 'Noise RTPC' in Radio class defaults — the noise volume will never change without it."));
}

TSet<TObjectPtr<class AStation>> ARadio::GetStationsInRange() const
{
	return StationsInRange;
}

void ARadio::Lock(const bool bEnable, AStation* Station)
{
	Super::Lock(bEnable);

	OnLock(bEnable, Station);
}

void ARadio::ShiftFrequency(const FInputActionValue& Value)
{
	check(KnobComponent);

	/* DEPRECATED
	if (FrequencyControlType == EFrequencyControlType::EFCT_Spin)
	{
		const FVector2d RecordedValue = Value.Get<FVector2D>();
		const float Length = RecordedValue.Length();
		const float Angle = UTLUtils::GetAngleFrom2DVector(RecordedValue);

		if (bIsNotFirstRollAngle)
		{
			if (Length < MinimumRollInputRegister)
			{
				bIsNotFirstRollAngle = false;
			}
			else
			{
				const float RelativeValue = UTLUtils::GetAngleDelta(Angle, LastAngle)) / 360.f;
				KnobComponent->ClockwiseRotate(RelativeValue);
				LastAngle = Angle;
			}
		}
		else
		{
			if (Length >= MinimumRollInputRegister)
			{
				bIsNotFirstRollAngle = true;
				LastAngle = Angle;
			}
		}
	}
	*/
	const float RelativeValue = Value.Get<float>();
	KnobComponent->ClockwiseRotate(RelativeValue, GetWorld()->GetDeltaSeconds());
}

FVector2d ARadio::GetFrequencyRange() const
{
	return FrequencyRange;
}

void ARadio::UpdateVisuals() const
{
	UpdateText();

	if (!ensure(ScreenComponent) || !ensure(KnobComponent))
	{
	}
}

void ARadio::UpdateText() const
{
	check(WidgetComponent);

	const FText NewText = FText::FromString(FString::Printf(TEXT("%.0f Hz"), KnobComponent->GetValue()));
	if (UUserWidget const *Widget = WidgetComponent->GetWidget(); ensure(Widget))
	{
		const URadioText* RadioText = Cast<URadioText>(Widget);
		check(RadioText);
		RadioText->SetRadioText(NewText);
	}
}

void ARadio::ActivateAnswers()
{
	// should call a function handled by the station
	if (APlayerController* PlayerController = UGameplayStatics::GetPlayerController(GetWorld(), 0))
	{
		if (ALukaHUD* LukaHUD = Cast<ALukaHUD>(PlayerController->GetHUD()))
		{
			LukaHUD->HandleAnswerInput();
		}
	}
}
