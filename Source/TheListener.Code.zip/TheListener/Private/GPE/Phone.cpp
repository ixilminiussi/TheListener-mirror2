#include "GPE/Phone.h"
#include "System/Core/PlayGameMode.h"
#include "Kismet/GameplayStatics.h"
#include "EnhancedInputComponent.h"
#include "AkComponent.h"
#include "Player/LukaController.h"
#include "Components/StaticMeshComponent.h"
#include "Components/BoxComponent.h"
#include "Components/SceneComponent.h"
#include "Components/TextRenderComponent.h"
#include "System/Events/EventAction.h"
#include "Miscellaneous/TLUtils.h"
#include "System/Dialogue/DialogueSubsystem.h"

APhone::APhone()
{
	PhoneBaseMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>("Phone Base");
	check(PhoneBaseMeshComponent);

	PhoneDialMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>("Phone Dial");
	check(PhoneDialMeshComponent);

	PhoneDialNumbersContainer = CreateDefaultSubobject<USceneComponent>(
		"Phone Dial number Container");
	check(PhoneDialNumbersContainer);

	check(PhoneDialNumbersContainer);


	PhoneBaseMeshComponent->SetupAttachment(CollisionComponent);
	PhoneDialMeshComponent->SetupAttachment(PhoneBaseMeshComponent);
	PhoneDialNumbersContainer->SetupAttachment(PhoneBaseMeshComponent);
	for (int i = 0; i < 10; i++)
	{
		FString NumberName = "Number_";
		NumberName.AppendInt(i);
		UTextRenderComponent* NumberWidget = CreateDefaultSubobject<UTextRenderComponent>(
			FName(*NumberName));
		NumberWidget->SetText(FText::FromString(FString::FromInt(i)));
		NumberWidget->SetupAttachment(PhoneDialNumbersContainer);
		InputNumberTextRenders.Add(NumberWidget);
	}

	for (int i = 0; i < 6; i++)
	{
		FString NumberName = "NumberDigit_";
		NumberName.AppendInt(i);

		UChildActorComponent* ChildActorComponent = CreateDefaultSubobject<
			UChildActorComponent>(FName(*NumberName));
		check(ChildActorComponent);
		ChildActorComponent->SetupAttachment(RootComponent);
		ChildActorComponent->bEditableWhenInherited = true;
		if (NumberDigitClass)
		{
			ChildActorComponent->SetChildActorClass(NumberDigitClass);
		}
		NumberDigits.Push(ChildActorComponent);
	}

	PhoneAkComponent = CreateDefaultSubobject<UAkComponent>(TEXT("PhoneAkComponent"));
	PhoneAkComponent->SetupAttachment(RootComponent);
}

void APhone::BeginPlay()
{
	Super::BeginPlay();

	if (!GetWorld()->GetSubsystem<UDialogueSubsystem>())
	{
		UE_LOG(LogTemp, Warning, TEXT("Missing Dialogue Subsystem in Scene. Needed for phone to work"));
		return;
	}
	GetWorld()->GetSubsystem<UDialogueSubsystem>()->EventOnDialogueEnd.AddDynamic(this, &APhone::OnEndStory);

	TArray<USceneComponent*> NumberComponents;
	PhoneDialNumbersContainer->GetChildrenComponents(false, NumberComponents);
	for (int i = 0; i < 10; i++)
	{
		FString NameToCheck = "Number_";
		NameToCheck.AppendInt(i);
		for (USceneComponent* NumberComp : NumberComponents)
		{
			FString NameOfComp;
			NumberComp->GetName(NameOfComp);
			if (NameOfComp == NameToCheck)
			{
				InputNumberTextRenders[i] = Cast<UTextRenderComponent>(NumberComp);
				InputNumberTextRenders[i]->SetTextRenderColor(UnselectedColor);
				break;
			}
		}
	}

	BaseRotation = PhoneDialMeshComponent->GetRelativeRotation();

	ClearDial();
}

void APhone::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	UEnhancedInputComponent* EnhancedInputComponent = Cast<UEnhancedInputComponent>(InputComponent);

	if (!ensure(EnhancedInputComponent != nullptr)) { return; }
	if (ensure(InputActionRotate != nullptr))
	{
		EnhancedInputComponent->BindAction(InputActionRotate, ETriggerEvent::Triggered, this,
		                                   &APhone::RotateDial);
		EnhancedInputComponent->BindAction(InputActionConfirm, ETriggerEvent::Started, this,
		                                   &APhone::ReleaseDial);
		EnhancedInputComponent->BindAction(InputActionClear, ETriggerEvent::Started, this,
		                                   &APhone::ClearDial);
	}
}

void APhone::GiveCallData(URingPhoneAction* IncomingCall)
{
	if (CurrentCall != nullptr || !IncomingCalls.IsEmpty())
	{
		//Add calls to queue if there is an active call
		IncomingCalls.Enqueue(IncomingCall);
		return;
	}

	RingPhone(IncomingCall);
}

void APhone::RingNextCall()
{
	TObjectPtr<URingPhoneAction> NewCall;
	IncomingCalls.Dequeue(NewCall);
	RingPhone(NewCall);
}

void APhone::RingPhone(URingPhoneAction* Call)
{
	CurrentCall = Call;
	bIsCallOnDelay = false;

	GetWorld()->GetTimerManager().SetTimer(CallTimerHandle, this, &APhone::EndCurrentCall, DelayToAnswer, false);

	if (PhoneAkComponent)
	{
		FOnAkPostEventCallback nullCallback;
		PhoneAkComponent->PostAkEvent(RingPlayEvent, 0, nullCallback);
	}
}

void APhone::AnswerCall()
{
	if (!ensure(CurrentCall))
	{
		return;
	}
	if (!ensure(CurrentCall->GetDialog())) { return; }
	LaunchCall(CurrentCall);
}

void APhone::EndCurrentCall()
{
	if (CurrentStory == nullptr && CurrentCall->GetIsImportant())
	{
		GiveCallData(CurrentCall);
	}

	CurrentStory = nullptr;
	CurrentCall = nullptr;
	bLocked = false;

	ClearDial();

	if (PhoneAkComponent)
	{
		FOnAkPostEventCallback nullCallback;
		PhoneAkComponent->PostAkEvent(RingStopEvent, 0, nullCallback);
	}
}

void APhone::LaunchCall(UEventGraphActionData* EventAction)
{
	GetWorld()->GetTimerManager().ClearTimer(CallTimerHandle);
	bLocked = true;

	if (PhoneAkComponent)
	{
		FOnAkPostEventCallback nullCallback;
		PhoneAkComponent->PostAkEvent(RingStopEvent, 0, nullCallback);
	}

	if (EventAction == nullptr) StoryToStart = DefaultCall;

	if (URingPhoneAction* RingPhoneAction = Cast<URingPhoneAction>(EventAction))
	{
		StoryToStart = RingPhoneAction->GetDialog();
		StartStory();
	}
	else
	{
		FInputModeUIOnly Input;
		GetWorld()->GetFirstPlayerController()->SetInputMode(Input);
		if (UUnlockPhoneAction* UnlockPhoneAction = Cast<UUnlockPhoneAction>(EventAction))
		{
			StoryToStart = UnlockPhoneAction->GetInkpotStory();
			GetWorld()->GetTimerManager().SetTimer(PeopleAnswerTimerHandle, this, &APhone::StartStory, UnlockPhoneAction->GetAnswerDelay(), false);
		}
		else
		{
			StoryToStart = DefaultCall;
			GetWorld()->GetTimerManager().SetTimer(PeopleAnswerTimerHandle, this, &APhone::StartStory, NoAnswerDelay, false);
		}
	}
}

void APhone::StartStory()
{
	if (!StoryToStart) return;
	UDialogueSubsystem* DialogueSubsystem = GetWorld()->GetSubsystem<UDialogueSubsystem>();
	if (!DialogueSubsystem)
	{
		UE_LOG(LogTemp, Warning, TEXT("Missing Dialogue Subsystem in Scene. Needed for phone to work"));
		return;
	}
	CurrentStory = DialogueSubsystem->StartStory(StoryToStart);
}

void APhone::OnEndStory(UInkpotStory* Story)
{
	if (Story == nullptr)
	{
		return;
	}
	if (Story == CurrentStory)
	{
		EndCurrentCall();
	}
}

void APhone::UnlockCall(UUnlockPhoneAction* CallToUnlock)
{
	TArray<UUnlockPhoneAction*> CallToRemove;
	for (UUnlockPhoneAction* Call : PossibleCall)
	{
		if (Call->GetNumber() == CallToUnlock->GetNumber())
		{
			CallToRemove.Add(Call);
		}
	}
	for (UUnlockPhoneAction* Call : CallToRemove)
	{
		PossibleCall.Remove(Call);
	}
	PossibleCall.Add(CallToUnlock);
}

void APhone::RotateDial(const FInputActionValue& Value)
{
	const FVector2d RecordedValue = Value.Get<FVector2D>();
	const float Length = RecordedValue.Length();
	float Angle = UTLUtils::GetAngleFrom2DVector(RecordedValue) - StartInputAngle;
	if (Angle < 0)
	{
		Angle += 360;
	}
	int NewNumber = (Angle / AngleDeltaForNumberSelection) + 1;
	if (NewNumber == 10) { NewNumber = 0; }
	if (NewNumber > 10) { NewNumber = -1; } //Invalid Number

	CurrentNumberSelected = NewNumber;
	if (CurrentNumberSelected != LastNumberSelected)
	{
		if (CurrentNumberSelected != -1)
		{
			InputNumberTextRenders[CurrentNumberSelected]->SetTextRenderColor(SelectedColor);
		}
		if (LastNumberSelected != -1)
		{
			InputNumberTextRenders[LastNumberSelected]->SetTextRenderColor(UnselectedColor);
		}
		LastNumberSelected = CurrentNumberSelected;
	}
}

void APhone::ReleaseDial(const FInputActionValue& Value)
{
	if (CurrentNumberSelected == -1) { return; } //Invalidate if current number is invalid
	if (CurrentNumberInput.Num() == 6)
	{
		ClearDial();
	}
	CurrentNumberInput.Push(CurrentNumberSelected);
	OnNumberUpdate_(CurrentNumberInput);
	UE_LOG(LogTemp, Log, TEXT("Selected %i ! Full number is %s"), CurrentNumberSelected,
	       *FString::JoinBy(CurrentNumberInput, TEXT(""), [](int32 Value){ return FString::FromInt(Value); }));
	if (CurrentNumberInput.Num() == 6)
	{
		UE_LOG(LogTemp, Log, TEXT("Calling %s !"),
			   *FString::JoinBy(CurrentNumberInput, TEXT(""), [](int32 Value){ return FString::FromInt(Value); }));
		bool bNumberFound = false;
		
		int CallingNumber = (((((CurrentNumberInput[0])*10+CurrentNumberInput[1])*10+CurrentNumberInput[2])*10+CurrentNumberInput[3])*10+CurrentNumberInput[4])*10+CurrentNumberInput[5];

		for (UUnlockPhoneAction* PhoneCallUnlocked : PossibleCall)
		{
			if (CallingNumber == PhoneCallUnlocked->GetNumber()[0])
			{
				if (!ensure(PhoneCallUnlocked->GetInkpotStory())) { break; }
				bNumberFound = true;
				LaunchCall(PhoneCallUnlocked);
			}
		}
		if (!bNumberFound) { LaunchCall(nullptr); }
	}
}

void APhone::ClearDial()
{
	CurrentNumberInput.Reset();
	OnNumberUpdate_(CurrentNumberInput);
}

void APhone::PossessedBy(AController* NewController)
{
	Super::PossessedBy(NewController);
	if (NewController != UGameplayStatics::GetPlayerController(GetWorld(), 0)) { return; }
	if (CurrentCall != nullptr) { AnswerCall(); }
	else
	{
		ClearDial();
	}
}

void APhone::UnPossessed()
{
	if (CurrentNumberSelected != -1)
	{
		InputNumberTextRenders[CurrentNumberSelected]->SetTextRenderColor(SelectedColor);
		ClearDial();
	}
	Super::UnPossessed();

	if (!IncomingCalls.IsEmpty())
	{
		FMath::RandInit(FMath::Rand());
		GetWorld()->GetTimerManager().SetTimer(CallTimerHandle, this, &APhone::RingNextCall,
											   FMath::RandRange(DelayForNextCall.X, DelayForNextCall.Y), false);
		bIsCallOnDelay = true;
	}
}
