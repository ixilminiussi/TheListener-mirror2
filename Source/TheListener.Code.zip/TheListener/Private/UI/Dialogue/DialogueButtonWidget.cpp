// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Dialogue/DialogueButtonWidget.h"

#include "Components/RichTextBlock.h"

void UDialogueButtonWidget::SetText(const FText& NewText)
{
	Text->SetText(NewText);
}
