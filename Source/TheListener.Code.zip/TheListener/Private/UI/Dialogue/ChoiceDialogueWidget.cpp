// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Dialogue/ChoiceDialogueWidget.h"
#include "CommonButtonBase.h"
#include "Components/Image.h"
#include "Components/VerticalBox.h"
#include "System/Dialogue/DialogueSubsystem.h"
#include "UI/Dialogue/DialogueButtonWidget.h"
#include "UI/Dialogue/DialogueWidget.h"

void UChoiceDialogueWidget::NativeConstruct()
{
	Super::NativeConstruct();
	
	//Create List of button
	ButtonsList.Add(Button1);
	ButtonsList.Add(Button2);
	ButtonsList.Add(Button3);
	ButtonsList.Add(Button4);
	
	for (int i = 0; i < ButtonsList.Num(); i++)
	{
		ensure(ButtonsList[i] != nullptr);
		ButtonsList[i]->OnClicked().AddUObject(this, &UChoiceDialogueWidget::SelectChoice,i);
	}

	ContinueButton->OnClicked.AddDynamic(this, &UChoiceDialogueWidget::Continue);
}

void UChoiceDialogueWidget::SelectChoice(int Choice)
{
	GetWorld()->GetSubsystem<UDialogueSubsystem>()->SelectChoice(Choice) ;
	DialogueWidget->SetContinueVisibility(ESlateVisibility::Visible);
}

void UChoiceDialogueWidget::Continue()
{
	if (ButtonBox->IsVisible())
	{
		DialogueWidget->SetContinueVisibility(ESlateVisibility::Hidden);
		return;
	}
	GetWorld()->GetSubsystem<UDialogueSubsystem>()->Continue();
}

void UChoiceDialogueWidget::HideAllButtons()
{
	for (UCommonButtonBase* Button : ButtonsList)
	{
		Button->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UChoiceDialogueWidget::SetButtonText(const FText& NewText, const int Choice)
{
	ButtonsList[Choice]->SetText(NewText);
}

void UChoiceDialogueWidget::SetButtonVisibility(ESlateVisibility NewVis, const int Choice)
{
	ButtonsList[Choice]->SetVisibility(NewVis);
}

void UChoiceDialogueWidget::SetDialogueText(const FText& NewText)
{
	DialogueWidget->SetText(NewText);
}

void UChoiceDialogueWidget::SetChoiceVisibility(ESlateVisibility NewVis)
{
	ButtonBox->SetVisibility(NewVis);
}

void UChoiceDialogueWidget::SetConfirmInputVisibility(ESlateVisibility NewVis)
{
	DialogueWidget->SetContinueVisibility(NewVis);
}

void UChoiceDialogueWidget::EnableConfirmInput(bool NewIsEnabled)
{
	ContinueButton->SetIsEnabled(NewIsEnabled);
}

void UChoiceDialogueWidget::EnableContinueButton(bool NewIsEnabled)
{
	ContinueButton->SetIsEnabled(NewIsEnabled);
}

void UChoiceDialogueWidget::SetFocusToButton()
{
	Button1->SetFocus();
}

void UChoiceDialogueWidget::SetFocusToContinueButton()
{
	ContinueButton->SetFocus();
}

void UChoiceDialogueWidget::SetContinueButtonVisibility(ESlateVisibility NewVis)
{
	ContinueButton->SetVisibility(NewVis);
}

