// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Menus/SettingsSave.h"
#include "Kismet/GameplayStatics.h"
#include "UI/Menus/SettingsDataAsset.h"

void USettingsSave::InitializeFromDefaults(USettingsDataAsset* DefaultData)
{
	if (!ensure(DefaultData))
	{
		return;
	}
	HorizontalSensitivity = DefaultData->HorizontalSensitivity;
	VerticalSensitivity = DefaultData->VerticalSensitivity;
	MasterVolume = DefaultData->MasterVolume;
	UGameplayStatics::SaveGameToSlot(this, TEXT("Settings"), 0);
}

void USettingsSave::SetHorizontalSensitivity(float Value)
{
	HorizontalSensitivity = Value;
	OnSettingsChanged.Broadcast();
	UGameplayStatics::SaveGameToSlot(this, TEXT("Settings"), 0);
}

void USettingsSave::SetVerticalSensitivity(float Value)
{
	VerticalSensitivity = Value;
	OnSettingsChanged.Broadcast();
	UGameplayStatics::SaveGameToSlot(this, TEXT("Settings"), 0);
}

void USettingsSave::SetControllerHapticFeedback(bool bValue)
{
	ControllerHapticFeedback = bValue;
	OnSettingsChanged.Broadcast();
	UGameplayStatics::SaveGameToSlot(this, TEXT("Settings"), 0);
}

void USettingsSave::SetMasterVolume(float Value)
{
	MasterVolume = Value;
	OnSettingsChanged.Broadcast();
	UGameplayStatics::SaveGameToSlot(this, TEXT("Settings"), 0);
}

float USettingsSave::GetHorizontalSensitivity() const
{
	return HorizontalSensitivity;
}

float USettingsSave::GetVerticalSensitivity() const
{
	return VerticalSensitivity;
}

bool USettingsSave::GetControllerHapticFeedback() const
{
	return ControllerHapticFeedback;
}

float USettingsSave::GetMasterVolume() const
{
	return MasterVolume;
}
