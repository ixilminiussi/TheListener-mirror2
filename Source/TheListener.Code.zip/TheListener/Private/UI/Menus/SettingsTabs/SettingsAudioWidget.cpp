// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Menus/SettingsTabs/SettingsAudioWidget.h"

#include "AkRtpc.h"
#include "Components/Slider.h"
#include "System/Core/BaseGameInstance.h"
#include "UI/Menus/SettingsSave.h"
#include "UI/Menus/UIElements/SliderSettings.h"

void USettingsAudioWidget::NativeConstruct()
{
	Super::NativeConstruct();

	check(MasterSlider);

	UBaseGameInstance* GI = Cast<UBaseGameInstance>(GetWorld()->GetGameInstance());
	check(GI);
	USettingsSave* SettingsSave = GI->GetSettingsSave();
	check(SettingsSave);

	MasterSlider->SetNumberSlider(SettingsSave->GetMasterVolume());
	MasterSlider->GetSlider()->OnValueChanged.AddDynamic(
		this, &USettingsAudioWidget::OnMasterSliderValueChanged);
}


void USettingsAudioWidget::OnMasterSliderValueChanged(float Value)
{
	UBaseGameInstance* GI = Cast<UBaseGameInstance>(GetWorld()->GetGameInstance());
	check(GI);

	USettingsSave* SettingsSave = GI->GetSettingsSave();
	check(SettingsSave);

	SettingsSave->SetMasterVolume(Value);
}
