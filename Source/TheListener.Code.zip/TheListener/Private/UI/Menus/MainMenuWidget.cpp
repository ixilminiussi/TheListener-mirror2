#include "UI/Menus/MainMenuWidget.h"
#include "Components/CanvasPanel.h"

UButtonPrimary* UMainMenuWidget::GetFocusedButton() const
{
	return ChangeLevelButton;
}

class UButton* UMainMenuWidget::GetPreMenuButton()
{
	return PreMenuButton;
}

void UMainMenuWidget::NativeConstruct()
{
	Super::NativeConstruct();
}

void UMainMenuWidget::OnChangeLevelClicked() const
{
	Super::OnChangeLevelClicked();
}

void UMainMenuWidget::OnQuitClicked() const
{
	Super::OnQuitClicked();
}

void UMainMenuWidget::OnSettingsClicked() const
{
	Super::OnSettingsClicked();
}

void UMainMenuWidget::SetFocusOnMainMenu()
{
	ChangeLevelButton->SetUserFocus(GetWorld()->GetFirstPlayerController());
	ChangeLevelButton->SetKeyboardFocus();
}
