// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Menus/BaseMenuWidget.h"

#include "Components/VerticalBox.h"
#include "Engine/AssetManager.h"
#include "Engine/StreamableManager.h"
#include "Kismet/GameplayStatics.h"
#include "System/Core/BaseGameInstance.h"
#include "UI/BaseHUD.h"
#include "UI/Menus/SettingsMenuWidget.h"
#include "UI/Menus/SettingsSave.h"
#include "UI/Menus/SettingsTabs/SettingsTabBase.h"
#include "UI/Menus/UIElements/ButtonPrimary.h"

UButtonPrimary* UBaseMenuWidget::GetFocusedButton() const
{
	return nullptr;
}

void UBaseMenuWidget::NativeConstruct()
{
	Super::NativeConstruct();

	APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0);

	FInputModeGameAndUI InputMode;
	InputMode.SetWidgetToFocus(this->TakeWidget());
	InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);

	if (ensure(PC))
	{
		PC->SetInputMode(InputMode);
		PC->SetShowMouseCursor(false);
		PC->bEnableClickEvents = false;
		PC->bEnableTouchEvents = false;
	}

	check(ChangeLevelButton);
	ChangeLevelButton->OnClicked().AddUObject(this, &UBaseMenuWidget::OnChangeLevelClicked);

	check(SettingsButton)
	SettingsButton->OnClicked().AddUObject(this, &UBaseMenuWidget::OnSettingsClicked);

	check(QuitButton);
	QuitButton->OnClicked().AddUObject(this, &UBaseMenuWidget::OnQuitClicked);
}

class UButton* UBaseMenuWidget::GetPreMenuButton()
{
	return nullptr;
}

void UBaseMenuWidget::OnChangeLevelClicked() const
{
	FSoftObjectPath Path = NewLevel.ToSoftObjectPath();
	FStreamableManager& Streamable = UAssetManager::GetStreamableManager();

	/* Streamable.RequestAsyncLoad(
		Path,
		FStreamableDelegate::CreateUObject(this, &UBaseMenuWidget::LoadNextLevel)
	); */

	OnStartLoadingScreen();
	LoadNextLevel();
}

void UBaseMenuWidget::LoadNextLevel() const
{
	UGameplayStatics::OpenLevelBySoftObjectPtr(GetWorld(), NewLevel);
}

void UBaseMenuWidget::OnSettingsClicked() const
{
	if (APlayerController* PC = GetOwningPlayer())
	{
		if (ABaseHUD* HUD = Cast<ABaseHUD>(PC->GetHUD()))
		{
			if (USettingsMenuWidget* Settings = HUD->GetSettingsMenuWidget())
			{
				Settings->SetVisibility(ESlateVisibility::Visible);
				HUD->GetPreviousWidget()->SetIsEnabled(false);
				Settings->GetSwitcherTabSettings()->GetAnimatedSwitcher()->SetActiveWidgetIndex(0);
				USettingsTabBase* CurrentWidget = Cast<USettingsTabBase>(
				Settings->GetSwitcherTabSettings()->GetAnimatedSwitcher()->GetWidgetAtIndex(0));
				CurrentWidget->GetVerticalBox()->GetChildAt(0)->SetFocus();


				UBaseGameInstance* GI = Cast<UBaseGameInstance>(GetWorld()->GetGameInstance());
				check(GI);
				USettingsSave* SettingsSave = GI->GetSettingsSave();
				check(SettingsSave);
				USettingsTabBase* GameplayTab = Settings->GetSwitcherTabSettings()->GetGameplayTab();
				check(GameplayTab);
				GameplayTab->SetupSettingsValues(SettingsSave);
			}
		}
	}
}

void UBaseMenuWidget::OnQuitClicked() const
{
	UKismetSystemLibrary::QuitGame(this, nullptr, EQuitPreference::Quit, false);
}
