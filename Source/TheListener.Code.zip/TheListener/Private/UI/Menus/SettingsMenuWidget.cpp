// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Menus/SettingsMenuWidget.h"

#include "CommonAnimatedSwitcher.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "Components/VerticalBox.h"
#include "Ink/InkList.h"
#include "Kismet/GameplayStatics.h"
#include "UI/Menus/MainMenuHUD.h"
#include "UI/Menus/MainMenuWidget.h"
#include "UI/Menus/SettingsTabs/SettingsTabBase.h"
#include "UI/Menus/UIElements/ButtonPrimary.h"
#include "UI/Menus/UIElements/SliderSettings.h"

USwitcherTabSettings* USettingsMenuWidget::GetSwitcherTabSettings() const
{
	return SwitcherTabSettings;
}

void USettingsMenuWidget::NativeConstruct()
{
	Super::NativeConstruct();
}

bool USettingsMenuWidget::GetIsEnhanced() const
{
	return bIsEnhanced;
}

void USettingsMenuWidget::SetIsEnhanced(bool NewIsEnhanced)
{
	bIsEnhanced = NewIsEnhanced;
}

FReply USettingsMenuWidget::NativeOnKeyDown(const FGeometry& InGeometry, const FKeyEvent& InKeyEvent)
{
	if (InKeyEvent.GetKey() == EKeys::Gamepad_RightShoulder)
	{
		ToRightTab();
	}
	if (InKeyEvent.GetKey() == EKeys::Gamepad_LeftShoulder)
	{
		ToLeftTab();
	}
	if (InKeyEvent.GetKey() == EKeys::Gamepad_FaceButton_Right)
	{
		Return();
	}

	return Super::NativeOnKeyDown(InGeometry, InKeyEvent);
}

void USettingsMenuWidget::ToRightTab() const
{
	int32 NewIndex = (SwitcherTabSettings->GetAnimatedSwitcher()->GetActiveWidgetIndex() + 1) % 4;

	SwitcherTabSettings->GetAnimatedSwitcher()->SetActiveWidgetIndex(NewIndex);
	USettingsTabBase* CurrentWidget = Cast<USettingsTabBase>(
		SwitcherTabSettings->GetAnimatedSwitcher()->GetWidgetAtIndex(NewIndex));
	CurrentWidget->GetVerticalBox()->GetChildAt(0)->SetFocus();
}

void USettingsMenuWidget::ToLeftTab() const
{
	int32 NewIndex = (SwitcherTabSettings->GetAnimatedSwitcher()->GetActiveWidgetIndex() + 4 - 1) % 4;

	SwitcherTabSettings->GetAnimatedSwitcher()->SetActiveWidgetIndex(NewIndex);
	USettingsTabBase* CurrentWidget = Cast<USettingsTabBase>(
		SwitcherTabSettings->GetAnimatedSwitcher()->GetWidgetAtIndex(NewIndex));
	CurrentWidget->GetVerticalBox()->GetChildAt(0)->SetFocus();
}

void USettingsMenuWidget::Return() const
{
	const APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0);
	ABaseHUD* HUD = Cast<ABaseHUD>(PC->GetHUD());
	if (ensure(HUD))
	{
		HUD->GetPreviousWidget()->SetIsEnabled(true);
		HUD->GetPreviousWidget()->GetFocusedButton()->SetFocus();
		HUD->GetSettingsMenuWidget()->SetVisibility(ESlateVisibility::Collapsed);
	}
}
