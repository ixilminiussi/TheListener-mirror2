// Copyright (c) 2025 ArtFX. Created by Team FalseStart. All rights reserved.


#include "UI/Menus/UIElements/RichTextBlocDropDown.h"

#include "Components/RichTextBlock.h"

class URichTextBlock* URichTextBlocDropDown::GetRichTextBlock() const
{
	return RichTextBlock;
}

void URichTextBlocDropDown::NativeConstruct()
{
	Super::NativeConstruct();

	/*if (!RichTextBlock)
	{
		return;
	}
	RichTextBlock->SetText(Text);*/
}
