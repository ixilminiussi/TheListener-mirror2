// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Menus/UIElements/ButtonPrimary.h"

#include "Components/RichTextBlock.h"
#include "Components/TextBlock.h"

void UButtonPrimary::NativeConstruct()
{
	Super::NativeConstruct();

	if (!TextBlock)
	{
		return;
	}

	TextBlock->SetText(Text);
}
