// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Menus/UIElements/SliderSettings.h"

#include "EnhancedInputComponent.h"
#include "Components/RichTextBlock.h"
#include "Components/Slider.h"
#include "Kismet/GameplayStatics.h"
#include "UI/BaseHUD.h"
#include "UI/Menus/SettingsMenuWidget.h"
#include "UI/Menus/SettingsSave.h"

void USliderSettings::NativeConstruct()
{
	Super::NativeConstruct();

	HUD = Cast<ABaseHUD>(UGameplayStatics::GetPlayerController(GetWorld(), 0)->GetHUD());

	if (ensure(RichTextBlock))
	{
		RichTextBlock->SetText(Text);
	}

	if (!ensure(Slider))
	{
		return;
	}

	Slider->SetMaxValue(SliderMax);
	Slider->SetMinValue(SliderMin);
	Slider->SetStepSize(SliderStepSize);

	SetNumberSlider(Slider->GetValue());

	Slider->IsFocusable = false;
	Slider->SetVisibility(ESlateVisibility::HitTestInvisible);
}

void USliderSettings::NativeOnHovered()
{
	bEnabled = true;

	Slider->SetIsEnabled(true);

	Super::NativeOnHovered();
}

void USliderSettings::NativeOnUnhovered()
{
	bEnabled = false;

	Slider->SetIsEnabled(false);

	Super::NativeOnUnhovered();
}

FReply USliderSettings::NativeOnPreviewKeyDown(const FGeometry& InGeometry, const FKeyEvent& InKeyEvent)
{
	if (InKeyEvent.GetKey() == EKeys::Gamepad_DPad_Left)
	{
		OnLeftDpadClicked();
	}

	if (InKeyEvent.GetKey() == EKeys::Gamepad_DPad_Right)
	{
		OnRightDpadClicked();
	}

	return Super::NativeOnPreviewKeyDown(InGeometry, InKeyEvent);
}

FReply USliderSettings::NativeOnAnalogValueChanged(const FGeometry& InGeometry, const FAnalogInputEvent& InAnalogEvent)
{
	const float CurrentCall = UGameplayStatics::GetRealTimeSeconds(GetWorld());

	constexpr float JitterTime = 0.1f;
	if (CurrentCall - LastCall < JitterTime)
	{
		return FReply::Unhandled();
	}

	if (InAnalogEvent.GetKey() == EKeys::Gamepad_LeftX)
	{
		if (InAnalogEvent.GetAnalogValue() < -0.2)
		{
			OnLeftDpadClicked();
			LastCall = CurrentCall;
		}
		if (InAnalogEvent.GetAnalogValue() > 0.2)
		{
			OnRightDpadClicked();
			LastCall = CurrentCall;
		}
	}
	return Super::NativeOnAnalogValueChanged(InGeometry, InAnalogEvent);
}

class URichTextBlock* USliderSettings::GetValueRichTextBlock() const
{
	return ValueRichTextBlock;
}

void USliderSettings::OnLeftDpadClicked()
{
	if (!bEnabled)
	{
		return;
	}

	StepOnceGamepad(-1.0f * SliderStepSize);
}

void USliderSettings::OnRightDpadClicked()
{
	UE_LOG(LogTemp, Log, TEXT("I am %s"), GetName().GetCharArray().GetData());

	if (!bEnabled)
	{
		return;
	}

	StepOnceGamepad(1.0f * SliderStepSize);
}

void USliderSettings::SetNumberSlider(const float Value) const
{
	Slider->SetValue(Value);

	FNumberFormattingOptions NumberFormat;
	NumberFormat.MinimumFractionalDigits = 0;

	if (FMath::IsNearlyEqual(Value, FMath::RoundToFloat(Value)))
	{
		NumberFormat.MaximumFractionalDigits = 0;
	}
	else
	{
		NumberFormat.MaximumFractionalDigits = 2;
	}

	check(ValueRichTextBlock)
	ValueRichTextBlock->SetText(
		FText::AsNumber(Value, &NumberFormat));
}

void USliderSettings::StepOnceGamepad(float StepAmount)
{
	if (!bEnabled)
	{
		return;
	}

	check(Slider)
	float Current = Slider->GetValue();
	Current += StepAmount * 1.f;
	Current = FMath::Clamp(Current, SliderMin, SliderMax);
	SetNumberSlider(Current);
}

class USlider* USliderSettings::GetSlider() const
{
	return Slider;
}
