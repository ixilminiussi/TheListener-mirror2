// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Menus/UIElements/WidgetTab.h"

#include "Components/Image.h"
#include "Components/RichTextBlock.h"

void UWidgetTab::NativeConstruct()
{
	Super::NativeConstruct();

	if (!RichTextBlock)
	{
		return;
	}

	RichTextBlock->SetText(Text);

	if (!DotImage)
	{
		return;
	}
	DotImage->SetBrush(DotBrush);

	if (!LineImage)
	{
		return;
	}
	if (bIsSelectedLine)
	{
		LineImage->SetVisibility(ESlateVisibility::Visible);
	}
	else
	{
		LineImage->SetVisibility(ESlateVisibility::Hidden);
	}
}

void UWidgetTab::NativePreConstruct()
{
	Super::NativeConstruct();

	if (!RichTextBlock)
	{
		return;
	}

	RichTextBlock->SetText(Text);
}
