// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Menus/UIElements/ButtonUIElement.h"

void UButtonUIElement::NativeConstruct()
{
	Super::NativeConstruct();

	SetNavigationRuleExplicit(EUINavigation::Up, UpUIElement);
	SetNavigationRuleExplicit(EUINavigation::Down, DownUIElement);
}

void UButtonUIElement::NativeOnClicked()
{
}
