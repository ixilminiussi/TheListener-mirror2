// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Menus/UIElements/DropdownSettings.h"
#include "CommonAnimatedSwitcher.h"
#include "Components/RichTextBlock.h"
#include "Kismet/GameplayStatics.h"
#include "UI/Menus/UIElements/RichTextBlocDropDown.h"


void UDropdownSettings::NativeConstruct()
{
	Super::NativeConstruct();

	/*const APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0);

	for (FText OptionText : DropdownValues)
	{
		CreateTextBlock(OptionText);
	}
	
	if (ensure(RichTextBlock != nullptr))
	{
		RichTextBlock->SetText(NameText);
	}
	*/
}

void UDropdownSettings::NativeOnClicked()
{
	Super::NativeOnClicked();
	
	/*if (bIsSelected)
	{
		//ComboBox->SetIsEnabled(false);
		bIsSelected = false;
	}
	else
	{
		//ComboBox->SetIsEnabled(true);
		bIsSelected = true;
	}*/
}

void UDropdownSettings::CreateTextBlock(FText Text)
{
	/*if (!Switcher || !RichTextBlocDropDownClass)
	{
		return;
	}

	APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0);
	check(PC);
	URichTextBlocDropDown* RichTextBlockDropdown = CreateWidget<URichTextBlocDropDown>(PC, RichTextBlocDropDownClass);
	check(RichTextBlockDropdown);
	Switcher->AddChild(RichTextBlockDropdown);
	RichTextBlockDropdown->GetRichTextBlock()->SetText(Text);
	RichTextBlockDropdown->GetRichTextBlock()->SetTextStyleSet(TextStyle);*/
}

