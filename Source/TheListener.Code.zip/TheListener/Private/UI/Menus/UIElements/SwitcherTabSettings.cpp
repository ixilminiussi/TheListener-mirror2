// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Menus/UIElements/SwitcherTabSettings.h"
#include "UI/Menus/UIElements/ButtonUIElement.h"

void USwitcherTabSettings::NativeConstruct()
{
	Super::NativeConstruct();
}

USettingsTabBase* USwitcherTabSettings::GetGameplayTab() const
{
	return GameplayTab;
}

USettingsTabBase* USwitcherTabSettings::GetAudioTab() const
{
	return AudioTab;
}

USettingsTabBase* USwitcherTabSettings::GetGraphicsTab() const
{
	return GraphicsTab;
}

USettingsTabBase* USwitcherTabSettings::GetAccessibilityTab() const
{
	return AccessibilityTab;
}


class UCommonAnimatedSwitcher* USwitcherTabSettings::GetAnimatedSwitcher() const
{
	return AnimatedSwitcher;
}
