#include "UI/SubtitleText.h"
#include "Components/RichTextBlock.h"

void USubtitleText::SetText(FString NewText)
{
	if (!ensure(SubtitleText)) { return; }
	SubtitleText->SetText(FText::FromString(NewText));
}