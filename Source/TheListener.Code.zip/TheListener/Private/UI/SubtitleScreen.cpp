// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/SubtitleScreen.h"
#include "Components/VerticalBox.h"
#include "UI/SubtitleText.h"
#include "Components/VerticalBoxSlot.h"

void USubtitleScreen::AddToContainer(USubtitleText* Subtitle)
{
	UVerticalBoxSlot* BoxSlot = SubtitleContainer->AddChildToVerticalBox(Subtitle);
	BoxSlot->SetSize(FSlateChildSize(ESlateSizeRule::Fill));
	BoxSlot->SetHorizontalAlignment(HAlign_Center);
	BoxSlot->SetVerticalAlignment(VAlign_Center);
}

void USubtitleScreen::RemoveFromContainer(USubtitleText* Subtitle)
{
	SubtitleContainer->RemoveChild(Subtitle);
}

USubtitleText* USubtitleScreen::CreateSubtitle()
{
	USubtitleText* Subtitle = CreateWidget<USubtitleText>(GetOwningPlayer(), SubtitleTextClass);
	Subtitle->AddToViewport();
	Subtitle->SetVisibility(ESlateVisibility::Visible);
	AddToContainer(Subtitle);
	return Subtitle;
}

void USubtitleScreen::DeleteSubtitle(USubtitleText* Subtitle)
{
	if (!ensure(Subtitle)) { return; }
	RemoveFromContainer(Subtitle);
	Subtitle->RemoveFromParent();
}
