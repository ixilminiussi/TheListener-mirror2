#include "UI/InspectWidget.h"

void UInspectWidget::Show_Implementation()
{
	AddToViewport();
}

void UInspectWidget::Hide_Implementation()
{
	RemoveFromParent();
}
