// Fill out your copyright notice in the Description page of Project Settings.


#include "System/Dialogue/DialogueSubsystem.h"

#include "Blueprint/UserWidget.h"
#include "GPE/Phone.h"
#include "Inkpot/Inkpot.h"
#include "Inkpot/InkpotStory.h"
#include "Kismet/GameplayStatics.h"
#include "Platforms/AkPlatform_Windows/AkWindowsInitializationSettings.h"
#include "System/Core/ListenerWorldSettings.h"
#include "System/Dialogue/DialogueSubsystemData.h"
#include "System/Events/EventCondition.h"
#include "EventSubsystem.h"
#include "UI/Dialogue/ChoiceDialogueWidget.h"

bool UDialogueSubsystem::ShouldCreateSubsystem(UObject* Outer) const
{
	const auto World = Cast<UWorld>(Outer);
	if (!World)
	{
		return false;
	}
	if (World->IsGameWorld())
	{
		if (World->WorldType == EWorldType::Game || World->WorldType == EWorldType::PIE)
		{
			AListenerWorldSettings* WorldSettings = Cast<AListenerWorldSettings>(World->GetWorldSettings());
			if (!WorldSettings)
			{
				return false;
			}

			const auto AllowedLevels = WorldSettings->AllowedLevels;

			for (const auto& Level : AllowedLevels)
			{
				if (Level.IsValid() && !Level.ToSoftObjectPath().IsValid())
				{
					continue;
				}

				if (UWorld* LoadedLevel = Level.LoadSynchronous())
				{
					if (World->GetName() == LoadedLevel->GetName())
					{
						return true;
					}
				}
			}
		}
	}
	return false;
}

void UDialogueSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

	auto World = GetWorld();
	if (!World || !World->IsGameWorld())
	{
		return;
	}
	AListenerWorldSettings* WorldSettings = Cast<AListenerWorldSettings>(World->GetWorldSettings());
	if (!WorldSettings)
	{
		return;
	}

	if (UDialogueSubsystemData* DialogueSubsystemData = WorldSettings->DialogueSubsystemData.LoadSynchronous())
	{
		this->DialogueWidgetClass = DialogueSubsystemData->DialogueWidgetClass;
	}
	
	FWorldDelegates::OnWorldInitializedActors.AddUObject(this, &UDialogueSubsystem::OnActorsInitialized);
	UE_LOG(LogTemp, Log, TEXT("UDialogueSubsystem Initialized"));
}

void UDialogueSubsystem::OnActorsInitialized(const FActorsInitializedParams& Params)
{
	UInkpot* InkpotSubsystem = GEngine->GetEngineSubsystem<UInkpot>();
	InkpotSubsystem->EventOnStoryBegin.AddDynamic(this, &UDialogueSubsystem::OnStoryBegin);

	GetWorld()->GetTimerManager().SetTimerForNextTick(
		FTimerDelegate::CreateUObject(this, &UDialogueSubsystem::InitDialogueWidget));

	AActor* PhoneActor = UGameplayStatics::GetActorOfClass(GetWorld(), APhone::StaticClass());
	Phone = Cast<APhone>(PhoneActor);
	ensure(Phone);
}

void UDialogueSubsystem::InitDialogueWidget()
{
	CurrentDialogueWidget = CreateWidget<UChoiceDialogueWidget>(GetWorld()->GetFirstPlayerController(),
	                                                            DialogueWidgetClass.Get());
	CurrentDialogueWidget->AddToViewport();
	CurrentDialogueWidget->SetVisibility(ESlateVisibility::Collapsed);
}

void UDialogueSubsystem::Deinitialize()
{
	Super::Deinitialize();
}

void UDialogueSubsystem::SelectChoice(int Choice)
{
	CurrentStory->ChooseChoiceIndex(Choice);
	Continue();
}

void UDialogueSubsystem::SetText()
{
	CurrentDialogueWidget->SetDialogueText(FText::FromString(CurrentStory->GetCurrentText()));
	CurrentDialogueWidget->HideAllButtons();
	int index = 0;
	for (UInkpotChoice* Choice : CurrentStory->GetCurrentChoices())
	{
		CurrentDialogueWidget->SetButtonText(Choice->GetText(), index);
		CurrentDialogueWidget->SetButtonVisibility(ESlateVisibility::Visible, index);
		index++;
	}
}

void UDialogueSubsystem::Continue()
{
	if (CurrentStory->CanContinue())
	{
		CurrentStory->Continue();
		return;
	}
	FinishStory();
}

void UDialogueSubsystem::SetChoicesVisibility(bool HasChoices)
{
	if (HasChoices)
	{
		CurrentDialogueWidget->SetChoiceVisibility(ESlateVisibility::Visible);
		CurrentDialogueWidget->SetConfirmInputVisibility(ESlateVisibility::Hidden);
		CurrentDialogueWidget->SetFocusToButton();
		CurrentDialogueWidget->EnableContinueButton(false);
		CurrentDialogueWidget->SetContinueButtonVisibility(ESlateVisibility::Hidden);
	}
	else
	{
		CurrentDialogueWidget->SetChoiceVisibility(ESlateVisibility::Hidden);
		CurrentDialogueWidget->SetVisibility(ESlateVisibility::Visible);
		CurrentDialogueWidget->SetFocusToContinueButton();
		CurrentDialogueWidget->EnableContinueButton(true);
		CurrentDialogueWidget->SetContinueButtonVisibility(ESlateVisibility::Visible);
	}
}

UInkpotStory* UDialogueSubsystem::StartStory(UInkpotStoryAsset* NewStory)
{
	UInkpot* InkpotSubsystem = GEngine->GetEngineSubsystem<UInkpot>();
	if (CurrentStory != nullptr) { InkpotSubsystem->EndStory(CurrentStory); }
	CurrentStory = InkpotSubsystem->BeginStory(NewStory);
	return CurrentStory;
}

void UDialogueSubsystem::OnStoryBegin(UInkpotStory* NewStory)
{
	CurrentStory = NewStory;
	NewStory->OnContinue().AddDynamic(this, &UDialogueSubsystem::OnStoryContinue);
	CurrentDialogueWidget->SetVisibility(ESlateVisibility::Visible);
	FInputModeUIOnly Input;
	//Input.SetWidgetToFocus(CurrentDialogueWidget->TakeWidget());
	GetWorld()->GetFirstPlayerController()->SetInputMode(Input);
	Continue();
}

void UDialogueSubsystem::OnStoryContinue(UInkpotStory* Story)
{
	SetChoicesVisibility(Story->HasChoices());
	SetText();
	CheckTags();
}

void UDialogueSubsystem::FinishStory()
{
	EventOnDialogueEnd.Broadcast(CurrentStory);
	CurrentDialogueWidget->SetVisibility(ESlateVisibility::Collapsed);
	FInputModeGameOnly Input;
	GetWorld()->GetFirstPlayerController()->SetInputMode(Input);
	CurrentStory = nullptr;
}

class APhone* UDialogueSubsystem::GetPhone()
{
	check(Phone);
	return Phone;
}

class UChoiceDialogueWidget* UDialogueSubsystem::GetCurrentDialogueWidget()
{
	return CurrentDialogueWidget;
}

void UDialogueSubsystem::CheckTags()
{
	TArray<FString> Tags = CurrentStory->GetCurrentTags();
	for (FString Tag : Tags)
	{
		FString TagCmd = Tag.LeftChop(Tag.Len() - 3);
		FString TagArgs = Tag.RightChop(3);
		if (TagCmd == "CD_")
		{
			bool EnableCondition = (TagArgs.LeftChop(Tag.Len() - 1)) != "!";
			FConditionKey ConditionKey = UInkpotCondition::GenerateKey(TagArgs);
			GetWorld()->GetSubsystem<UEventSubsystem>()->SetConditionValue(ConditionKey, EnableCondition, true);
			return;
		}
	}
}
