#include "System/Core/PlayGameMode.h"
#include "Kismet/GameplayStatics.h"
#include "GPE/Phone.h"
#include "System/Clues/ClueSubsystem.h"

void APlayGameMode::BeginPlay()
{
	Super::BeginPlay();
	const FVector Location(0.0f, 0.0f, 0.0f);
	const FRotator Rotation(0.0f, 0.0f, 0.0f);
	const FActorSpawnParameters SpawnInfo;
}
