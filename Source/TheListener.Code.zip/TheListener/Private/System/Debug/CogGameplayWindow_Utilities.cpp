#include "System/Debug/CogGameplayWindow_Utilities.h"

#include "CogCommon.h"
#include "GPE/Radio/KnobComponent.h"
#include "GPE/Radio/Radio.h"

#if ENABLE_COG
#include "CogWidgets.h"
#include "GPE/Radio/PrimaryStation.h"
#include "GPE/Radio/StationDataAsset.h"
#include "Kismet/GameplayStatics.h"
#endif

void FCogGameplayWindow_Utilities::Initialize()
{
	FCogWindow::Initialize();

#if ENABLE_COG
	bHasMenu = true;

	Config = GetConfig<UCogNarrationConfig_Utilities>();
#endif
}

void FCogGameplayWindow_Utilities::RenderHelp()
{
	ImGui::Text("This window displays several gameplay utilities for debugging");
}

void FCogGameplayWindow_Utilities::RenderContent()
{
	FCogWindow::RenderContent();

#if ENABLE_COG
	if (ImGui::Button("Quick End Primary Station"))
	{
		TArray<AActor*> StationActors{};
		UGameplayStatics::GetAllActorsOfClass(GetWorld(), AStation::StaticClass(), StationActors);
		AActor* RadioActor = UGameplayStatics::GetActorOfClass(GetWorld(), ARadio::StaticClass());
		if (ARadio* Radio = Cast<ARadio>(RadioActor))
		{
			check(Radio->KnobComponent);
			for (AActor* Actor : StationActors)
			{
				if (AStation* Station = Cast<AStation>(Actor))
				{
					if (Station->IsInRange(Radio->KnobComponent->GetValue()))
					{
						Station->OnStopStation();
						UE_LOG(LogTemp, Warning, TEXT("Successfully ended current primary station"));
					}
				}
			}
		}
	}

	const bool Open = ImGui::CollapsingHeader("InGame Stations", ImGuiTreeNodeFlags_DefaultOpen);
	if (Open && ImGui::BeginTable("Stations", 2,
	                              ImGuiTableFlags_Resizable | ImGuiTableFlags_Reorderable |
	                              ImGuiTableFlags_NoSavedSettings | ImGuiTableFlags_PreciseWidths |
	                              ImGuiTableFlags_Borders))
	{
		ImGui::TableSetupColumn("Stations");
		ImGui::TableSetupColumn("Frequency");
		ImGui::TableHeadersRow();

		TArray<AActor*> OutActors{};
		UGameplayStatics::GetAllActorsOfClass(GetWorld(), AStation::StaticClass(), OutActors);
		for (auto Station : OutActors)
		{
			if (AStation* CurrentStation = Cast<AStation>(Station))
			{
				ImGui::TableNextRow();
				ImGui::TableSetColumnIndex(0);
				ImGui::Text(TCHAR_TO_UTF8(*CurrentStation->GetStationData()->StationName));
				ImGui::TableSetColumnIndex(1);
				ImGui::Text("%d", static_cast<int>(CurrentStation->GetStationData()->Frequency));
			}
		}
		ImGui::EndTable();
	}
#endif
}

void FCogGameplayWindow_Utilities::RenderTick(float DeltaSeconds)
{
	FCogWindow::RenderTick(DeltaSeconds);
}
