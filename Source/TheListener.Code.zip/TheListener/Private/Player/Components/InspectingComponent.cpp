// Fill out your copyright notice in the Description page of Project Settings.


#include "Player/Components/InspectingComponent.h"

#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "Blueprint/UserWidget.h"
#include "Components/CanvasPanel.h"
#include "GPE/File.h"
#include "GPE/Toy.h"
#include "Player/LukaCharacter.h"
#include "Player/LukaController.h"
#include "UI/InspectWidget.h"
#include "UI/Prompt/CommandHUDComponent.h"

class UEnhancedInputLocalPlayerSubsystem;

UInspectingComponent::UInspectingComponent()
{
	PrimaryComponentTick.bCanEverTick = false;

	CommandHUDComponent = CreateDefaultSubobject<UCommandHUDComponent>("CommandHUD");
}

void UInspectingComponent::TurnOnTranslation(const struct FInputActionInstance&)
{
	if (CurrentWidget)
	{
		if (CurrentWidget->IsVisible())
		{
			UCanvasPanel* TextGroup = Cast<UCanvasPanel>(CurrentWidget->GetWidgetFromName(TEXT("Texts")));

			if (!ensure(TextGroup))
			{
				return;
			}

			TextGroup->SetVisibility(ESlateVisibility::Visible);
		}
	}
}

void UInspectingComponent::TurnOffTranslation(const struct FInputActionInstance&)
{
	if (CurrentWidget)
	{
		if (CurrentWidget->IsVisible())
		{
			UCanvasPanel* TextGroup = Cast<UCanvasPanel>(CurrentWidget->GetWidgetFromName(TEXT("Texts")));

			if (!ensure(TextGroup))
			{
				return;
			}

			TextGroup->SetVisibility(ESlateVisibility::Hidden);
		}
	}
}

UInputMappingContext* UInspectingComponent::GetInputMappingContext() const
{
	return InputMappingContext;
}

void UInspectingComponent::BeginPlay()
{
	Super::BeginPlay();

	if (const ALukaController* LukaController = Cast<ALukaController>(GetOwner()); ensure(LukaController))
	{
		LukaCharacter = LukaController->GetLukaCharacter();
		check(LukaCharacter);
	}

	check(CommandHUDComponent);
	CommandHUDComponent->Generate(InputMappingContext);
}

void UInspectingComponent::ReadFile(const IInspectable* Inspectable)
{
	check(Inspectable);

	if (CurrentWidget)
	{
		if (CurrentWidget->IsVisible())
		{
			return;
		}

		CurrentWidget->RemoveFromParent();
		CurrentWidget = nullptr;
	}

	if (WeakInputLocalPlayerSubsystem.IsValid())
	{
		check(LukaCharacter);
		WeakInputLocalPlayerSubsystem.Get()->RemoveMappingContext(LukaCharacter->GetLukaMappingContext());
		WeakInputLocalPlayerSubsystem.Get()->AddMappingContext(InputMappingContext, 1);
	}

	CurrentWidget = CreateWidget<UInspectWidget>(GetWorld(), Inspectable->GetInspectWidget());
	if (ensure(CurrentWidget != nullptr))
	{
		CurrentWidget->AddToViewport();
		CurrentWidget->Show();

		if (const AObji* Obji = LukaCharacter->GetHeldObji(); Obji != nullptr)
		{
			Obji->SetActiveWidgetVisibility(false);
		}
		if (const AToy* Toy = Cast<AToy>(GetWorld()->GetFirstPlayerController()->GetPawn()); Toy != nullptr)
		{
			Toy->SetActiveWidgetVisibility(false);
		}

		CommandHUDComponent->AddActiveToHUD();
	}
}

void UInspectingComponent::Leave(const FInputActionInstance& Instance)
{
	if (CurrentWidget)
	{
		if (CurrentWidget->IsVisible())
		{
			CurrentWidget->Hide();
			CurrentWidget->RemoveFromParent();
			CurrentWidget = nullptr;

			if (ensure(WeakInputLocalPlayerSubsystem.IsValid()))
			{
				check(LukaCharacter);
				WeakInputLocalPlayerSubsystem.Get()->RemoveMappingContext(InputMappingContext);
				WeakInputLocalPlayerSubsystem.Get()->AddMappingContext(LukaCharacter->GetLukaMappingContext(), 1);
			}
		}
	}

	if (const AObji* Obji = LukaCharacter->GetHeldObji(); Obji != nullptr)
	{
		Obji->SetActiveWidgetVisibility(true);
	}
	if (const AToy* Toy = Cast<AToy>(GetWorld()->GetFirstPlayerController()->GetPawn()); Toy != nullptr)
	{
		Toy->SetActiveWidgetVisibility(true);
	}
	CommandHUDComponent->RemoveActiveFromHUD();
}

void UInspectingComponent::Read(const FInputActionInstance& Instance)
{
	check(LukaCharacter);

	if (const IInspectable* Inspectable = Cast<IInspectable>(LukaCharacter->GetHeldObji()); Inspectable != nullptr)
	{
		ReadFile(Inspectable);
		return;
	}

	if (const IInspectable* Inspectable = Cast<IInspectable>(LukaCharacter->GetInteractableInView()); Inspectable != nullptr)
	{
		ReadFile(Inspectable);
	}
}

void UInspectingComponent::SetupInput(UEnhancedInputComponent* EnhancedInputComponent,
                                      UEnhancedInputLocalPlayerSubsystem* InputLocalPlayerSubsystem)
{
	check(InputLocalPlayerSubsystem);
	check(EnhancedInputComponent);

	WeakInputLocalPlayerSubsystem = TWeakObjectPtr<UEnhancedInputLocalPlayerSubsystem>(InputLocalPlayerSubsystem);

	if (ensure(InputActionLeave != nullptr))
	{
		EnhancedInputComponent->BindAction(InputActionLeave, ETriggerEvent::Triggered, this,
		                                   &UInspectingComponent::Leave);
	}
	if (ensure(InputActionRead != nullptr))
	{
		EnhancedInputComponent->BindAction(
			InputActionRead, ETriggerEvent::Triggered, this, &UInspectingComponent::Read);
	}
	if (ensure(InputActionVisibilityText != nullptr))
	{
		EnhancedInputComponent->BindAction(InputActionVisibilityText, ETriggerEvent::Started, this,
		                                   &UInspectingComponent::TurnOnTranslation);
		EnhancedInputComponent->BindAction(InputActionVisibilityText, ETriggerEvent::Completed, this,
		                                   &UInspectingComponent::TurnOffTranslation);
	}
}
